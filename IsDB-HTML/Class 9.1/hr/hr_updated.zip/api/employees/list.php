<?php
function handle_employees_list(): void {
  $status = $_GET['status'] ?? null;
  $pdo = db();

  if ($status === 'active' || $status === 'inactive') {
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE status = ? ORDER BY id DESC");
    $stmt->execute([$status]);
  } else {
    $stmt = $pdo->query("SELECT * FROM employees ORDER BY id DESC");
  }
  json_response(['ok' => true, 'employees' => $stmt->fetchAll()]);
}
