<?php

function handle_employees_update(int $id): void {
  // JSON body read
  $data = get_json_body();

  // fallback: যদি কোনো hosting এ JSON empty আসে, তখন POST data দেখবে
  if ((!is_array($data) || !$data) && !empty($_POST)) {
    $data = $_POST;
  }

  if (!is_array($data) || !$data) {
    json_response(['error' => 'Empty request body'], 422);
  }

  // ✅ emp_code added
  $allowed = [
    'emp_code',
    'name',
    'phone',
    'email',
    'department',
    'designation',
    'join_date',
    'default_shift_id',
    'status'
  ];

  $set = [];
  $vals = [];

  foreach ($allowed as $f) {
    if (!array_key_exists($f, $data)) continue;

    $v = $data[$f];

    // normalize strings
    if (is_string($v)) {
      $v = trim($v);
      if ($v === '') $v = null;
    }

    // cast default_shift_id
    if ($f === 'default_shift_id') {
      if ($v === null || $v === '') $v = null;
      else $v = (int)$v;
    }

    // validate status
    if ($f === 'status') {
      if ($v === null) continue;
      $v = strtolower((string)$v);
      if (!in_array($v, ['active', 'inactive'], true)) {
        json_response(['error' => 'Invalid status'], 422);
      }
    }

    $set[] = "$f = ?";
    $vals[] = $v;
  }

  if (!$set) {
    json_response(['error' => 'No fields to update'], 422);
  }

  $pdo = db();

  // update
  $vals[] = $id;
  $sql = "UPDATE employees SET " . implode(', ', $set) . " WHERE id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute($vals);

  $changed = $stmt->rowCount(); // 0 means no change OR same values

  // fetch updated row (always return to verify)
  $st2 = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
  $st2->execute([$id]);
  $emp = $st2->fetch(PDO::FETCH_ASSOC);

  if (!$emp) {
    json_response(['error' => 'Employee not found'], 404);
  }

  $actor = $_SESSION['user']['id'] ?? null;
  audit_log($actor ? (int)$actor : null, 'UPDATE_EMPLOYEE', [
    'employee_id' => $id,
    'changed_rows' => $changed,
    'fields' => array_keys($data)
  ]);

  json_response([
    'ok' => true,
    'changed' => $changed,
    'employee' => $emp
  ]);
}
