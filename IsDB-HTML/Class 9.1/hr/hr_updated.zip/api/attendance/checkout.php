<?php
require __DIR__ . '/_helpers.php';

function handle_checkout(): void {
  $user = require_login();
  if (($user['role'] ?? '') !== 'employee') json_response(['error' => 'Only employees can check-out'], 403);

  $pdo = db();

  // If attendance is closed, optionally block checkout too (keeps policy consistent with check-in).
  $settings = $pdo->query("SELECT * FROM attendance_settings WHERE id = 1")->fetch();
  if ($settings && !(int)$settings['attendance_open']) {
    json_response(['error' => 'Attendance is closed by admin'], 403);
  }

  // --- IP restriction ---
  $ip = client_ip();
  $uStmt = $pdo->prepare("SELECT allowed_ip FROM users WHERE id = ? LIMIT 1");
  $uStmt->execute([(int)$user['id']]);
  $uRow = $uStmt->fetch();
  $userAllowed = trim((string)($uRow['allowed_ip'] ?? ''));

  if ($userAllowed !== '' && !ip_allowed($ip, $userAllowed)) {
    json_response(['error' => 'You can only check-out from your assigned network'], 403);
  }

  if ($userAllowed === '' && $settings && (int)$settings['ip_restriction_enabled']) {
    $globalAllowed = (string)($settings['allowed_ips'] ?? '');
    if (!ip_allowed($ip, $globalAllowed)) {
      json_response(['error' => 'IP not allowed'], 403);
    }
  }
  $employee_id = (int)$user['employee_id'];
  $date = today_date();
  $now = new DateTime('now', new DateTimeZone('Asia/Dhaka'));
  $nowStr = $now->format('Y-m-d H:i:s');

  $stmt = $pdo->prepare("SELECT * FROM attendance_logs WHERE employee_id = ? AND work_date = ? LIMIT 1");
  $stmt->execute([$employee_id, $date]);
  $log = $stmt->fetch();
  if (!$log || !$log['check_in']) json_response(['error' => 'You must check-in first'], 409);
  if ($log['check_out']) json_response(['error' => 'Already checked out'], 409);

  // Earliest checkout rule (optional by shift)
  $shift = resolve_employee_shift($pdo, $employee_id, $date);
  if (!empty($shift['checkout_earliest_time'])) {
    $earliest = new DateTime($date.' '.$shift['checkout_earliest_time'], new DateTimeZone('Asia/Dhaka'));
    if ($now < $earliest) json_response(['error' => 'Checkout not allowed yet'], 403);
  }

  $checkIn = new DateTime($log['check_in'], new DateTimeZone('Asia/Dhaka'));
  $totalMinutes = (int)floor(($now->getTimestamp() - $checkIn->getTimestamp()) / 60);

  // Early leave calc (if checked out before shift end)
  $end = new DateTime($date.' '.$shift['end_time'], new DateTimeZone('Asia/Dhaka'));
  $earlyLeaveMinutes = 0;
  if ($now < $end) $earlyLeaveMinutes = (int)floor(($end->getTimestamp() - $now->getTimestamp()) / 60);

  // Status: if total < min_daily => short hours (keep present but note)
  $status = $log['status'] ?: 'present';
  if ($status === 'incomplete') $status = 'present';

  $upd = $pdo->prepare("UPDATE attendance_logs SET check_out=?, total_minutes=?, early_leave_minutes=?, status=?, updated_at=? WHERE id=?");
  $upd->execute([$nowStr, $totalMinutes, $earlyLeaveMinutes, $status, now_dt(), (int)$log['id']]);

  audit_log((int)$user['id'], 'CHECKOUT', ['employee_id' => $employee_id, 'date' => $date, 'total_minutes' => $totalMinutes]);
  json_response(['ok' => true, 'date' => $date, 'check_out' => $nowStr, 'total_minutes' => $totalMinutes, 'early_leave_minutes' => $earlyLeaveMinutes]);
}
