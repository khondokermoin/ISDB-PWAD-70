<?php
declare(strict_types=1);

$config = require __DIR__ . '/config.php';

// --- Sessions ---
$secure = (bool)($config['session']['cookie_secure'] ?? true);
$samesite = $config['session']['cookie_samesite'] ?? 'Lax';

session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'domain' => '',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => $samesite,
]);
session_start();

// --- DB ---
function db(): PDO {
  static $pdo = null;
  if ($pdo) return $pdo;

  $config = require __DIR__ . '/config.php';
  $db = $config['db'];
  $dsn = sprintf("mysql:host=%s;dbname=%s;charset=%s", $db['host'], $db['name'], $db['charset'] ?? 'utf8mb4');

  $pdo = new PDO($dsn, $db['user'], $db['pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
  ]);
  return $pdo;
}

// --- Response helpers ---
function json_response($data, int $status = 200): void {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function get_json_body(): array {
  $raw = file_get_contents('php://input') ?: '';
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function method(): string {
  $m = $_SERVER['REQUEST_METHOD'] ?? 'GET';
  // Allow method override from POST
  if ($m === 'POST') {
    $override = $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? ($_POST['_method'] ?? null);
    if ($override) $m = strtoupper((string)$override);
  }
  return strtoupper($m);
}

function require_login(): array {
  if (!isset($_SESSION['user'])) json_response(['error' => 'Unauthorized'], 401);
  return $_SESSION['user'];
}

function require_admin(): array {
  $u = require_login();
  if (($u['role'] ?? '') !== 'admin') json_response(['error' => 'Forbidden'], 403);
  return $u;
}

function now_dt(): string {
  return (new DateTime('now', new DateTimeZone('Asia/Dhaka')))->format('Y-m-d H:i:s');
}

function today_date(): string {
  return (new DateTime('now', new DateTimeZone('Asia/Dhaka')))->format('Y-m-d');
}

function parse_path(): array {
  // Works for /api/index.php/... or /api/...
  $uri = $_SERVER['REQUEST_URI'] ?? '/';
  $qpos = strpos($uri, '?');
  if ($qpos !== false) $uri = substr($uri, 0, $qpos);

  // Normalize to remove leading /api
  $uri = preg_replace('#^/api(?:/index\.php)?#', '', $uri);
  $uri = trim($uri, '/');
  $parts = $uri === '' ? [] : explode('/', $uri);
  return $parts;
}

function audit_log(?int $actor_user_id, string $action, array $meta = []): void {
  try {
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO audit_logs (actor_user_id, action, meta_json, created_at) VALUES (?, ?, ?, ?)");
    $stmt->execute([$actor_user_id, $action, json_encode($meta, JSON_UNESCAPED_UNICODE), now_dt()]);
  } catch (Throwable $e) {
    // Don't block the main flow
  }
}

// --- IP helpers ---
// Best-effort client IP. If you are behind a reverse proxy/CDN, configure it to pass
// the real client IP via headers, and ensure your proxy strips spoofed headers.
function client_ip(): string {
  // Cloudflare
  if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) return trim((string)$_SERVER['HTTP_CF_CONNECTING_IP']);

  // Standard proxy header: take the first IP
  if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $xff = (string)$_SERVER['HTTP_X_FORWARDED_FOR'];
    $parts = array_map('trim', explode(',', $xff));
    if (!empty($parts[0])) return $parts[0];
  }

  if (!empty($_SERVER['HTTP_X_REAL_IP'])) return trim((string)$_SERVER['HTTP_X_REAL_IP']);
  return trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
}

function ip_in_cidr(string $ip, string $cidr): bool {
  if (strpos($cidr, '/') === false) return $ip === $cidr;
  [$subnet, $maskBits] = explode('/', $cidr, 2);
  $maskBits = (int)$maskBits;

  // Only IPv4 supported in this starter (common for office networks). If you need IPv6,
  // extend this using inet_pton/bitmask operations.
  $ipLong = ip2long($ip);
  $subLong = ip2long($subnet);
  if ($ipLong === false || $subLong === false) return false;

  if ($maskBits < 0 || $maskBits > 32) return false;
  $mask = $maskBits === 0 ? 0 : (-1 << (32 - $maskBits));
  return (($ipLong & $mask) === ($subLong & $mask));
}

// $allowed can be a single IP, a comma-separated list, and/or CIDR blocks.
function ip_allowed(string $clientIp, string $allowed): bool {
  $allowed = trim($allowed);
  if ($allowed === '') return true;

  $list = array_filter(array_map('trim', explode(',', $allowed)));
  if (!$list) return true;

  foreach ($list as $entry) {
    if ($entry === '') continue;
    if (ip_in_cidr($clientIp, $entry)) return true;
  }
  return false;
}
