<?php
function handle_login(): void {
  $data = get_json_body();
  $username = trim((string)($data['username'] ?? ''));
  $password = (string)($data['password'] ?? '');

  if ($username === '' || $password === '') {
    json_response(['error' => 'Username and password required'], 422);
  }

  $pdo = db();
  $stmt = $pdo->prepare("SELECT id, role, password_hash, is_active, employee_id FROM users WHERE username = ? OR email = ? OR phone = ? LIMIT 1");
  $stmt->execute([$username, $username, $username]);
  $u = $stmt->fetch();

  if (!$u || !(int)$u['is_active'] || !password_verify($password, $u['password_hash'])) {
    json_response(['error' => 'Invalid credentials'], 401);
  }

  // Load employee profile if employee role
  $employee = null;
  if ($u['role'] === 'employee' && $u['employee_id']) {
    $s2 = $pdo->prepare("SELECT id, emp_code, name, department, designation, status, default_shift_id FROM employees WHERE id = ? LIMIT 1");
    $s2->execute([(int)$u['employee_id']]);
    $employee = $s2->fetch();
  }

  $_SESSION['user'] = [
    'id' => (int)$u['id'],
    'role' => $u['role'],
    'employee_id' => $u['employee_id'] ? (int)$u['employee_id'] : null,
    'employee' => $employee,
  ];

  $pdo->prepare("UPDATE users SET last_login_at = ? WHERE id = ?")->execute([now_dt(), (int)$u['id']]);

  audit_log((int)$u['id'], 'LOGIN', []);
  json_response(['ok' => true, 'user' => $_SESSION['user']]);
}
