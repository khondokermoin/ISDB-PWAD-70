<?php
function handle_employees_create(): void {
  $data = get_json_body();
  $emp_code = trim((string)($data['emp_code'] ?? ''));
  $name = trim((string)($data['name'] ?? ''));
  $phone = trim((string)($data['phone'] ?? ''));
  $email = trim((string)($data['email'] ?? ''));
  $department = trim((string)($data['department'] ?? ''));
  $designation = trim((string)($data['designation'] ?? ''));
  $join_date = (string)($data['join_date'] ?? date('Y-m-d'));
  $default_shift_id = isset($data['default_shift_id']) ? (int)$data['default_shift_id'] : null;

  // Create login for employee
  $username = trim((string)($data['username'] ?? $emp_code));
  $password = (string)($data['password'] ?? '');
  $allowed_ip = trim((string)($data['allowed_ip'] ?? ''));
  $allowed_mac = trim((string)($data['allowed_mac'] ?? ''));

  if ($emp_code === '' || $name === '' || $username === '' || $password === '') {
    json_response(['error' => 'emp_code, name, username, password required'], 422);
  }

  // Validate allowed_ip (optional). Supports single IP, comma-separated list, and CIDR blocks (IPv4).
  if ($allowed_ip !== '') {
    $entries = array_filter(array_map('trim', explode(',', $allowed_ip)));
    foreach ($entries as $entry) {
      if ($entry === '') continue;
      if (strpos($entry, '/') !== false) {
        [$base, $bits] = explode('/', $entry, 2);
        $bits = (int)$bits;
        if (!filter_var($base, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || $bits < 0 || $bits > 32) {
          json_response(['error' => 'Invalid allowed_ip (use IPv4 or CIDR, e.g. 203.0.113.10 or 203.0.113.0/24)'], 422);
        }
      } else {
        if (!filter_var($entry, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
          json_response(['error' => 'Invalid allowed_ip (use IPv4, e.g. 203.0.113.10)'], 422);
        }
      }
    }
  }

  // Validate allowed_mac (optional). Supports single MAC or comma-separated list.
  if ($allowed_mac !== '') {
    $entries = array_filter(array_map('trim', explode(',', $allowed_mac)));
    foreach ($entries as $entry) {
      if ($entry === '') continue;
      if (mac_normalize($entry) === '') {
        json_response(['error' => 'Invalid allowed_mac (use format like AA:BB:CC:DD:EE:FF)'], 422);
      }
    }
  }

  $pdo = db();
  $pdo->beginTransaction();
  try {
    $stmt = $pdo->prepare("INSERT INTO employees (emp_code, name, phone, email, department, designation, join_date, status, default_shift_id, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)");
    $stmt->execute([$emp_code, $name, $phone, $email, $department, $designation, $join_date, $default_shift_id, now_dt()]);
    $employee_id = (int)$pdo->lastInsertId();

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt2 = $pdo->prepare("INSERT INTO users (role, username, email, phone, allowed_ip, allowed_mac, password_hash, employee_id, is_active, created_at)
                            VALUES ('employee', ?, ?, ?, ?, ?, ?, ?, 1, ?)");
    $stmt2->execute([
      $username,
      $email ?: null,
      $phone ?: null,
      $allowed_ip !== '' ? $allowed_ip : null,
      $allowed_mac !== '' ? $allowed_mac : null,
      $hash,
      $employee_id,
      now_dt()
    ]);

    $pdo->commit();

    $actor = $_SESSION['user']['id'] ?? null;
    audit_log($actor ? (int)$actor : null, 'CREATE_EMPLOYEE', ['employee_id' => $employee_id, 'emp_code' => $emp_code]);

    json_response(['ok' => true, 'employee_id' => $employee_id], 201);
  } catch (Throwable $e) {
    $pdo->rollBack();
    json_response(['error' => 'Create failed', 'detail' => $e->getMessage()], 400);
  }
}
