<?php
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'u951246149_hr_attendance',
    'user' => 'u951246149_hr_user',
    'pass' => '(S47i61t56o08L)',
    'charset' => 'utf8mb4',
  ],
  'session' => [
    'cookie_secure' => true,
    'cookie_samesite' => 'Lax',
  ],
];
