<?php
function handle_shifts_update(int $id): void {
  $d = get_json_body();

  $fields = ['name','start_time','end_time','grace_minutes'];
  $set = [];
  $vals = [];

  foreach ($fields as $f) {
    if (array_key_exists($f, $d)) {
      $val = $d[$f];

      if ($f === 'name') {
        $val = trim((string)$val);
        if ($val === '') json_response(['error' => 'Name required'], 422);
      }

      if ($f === 'start_time' || $f === 'end_time') {
        $val = (string)$val;
        if (!preg_match('/^\d{2}:\d{2}:\d{2}$/', $val)) {
          json_response(['error' => $f.' must be HH:MM:SS'], 422);
        }
      }

      if ($f === 'grace_minutes') {
        $val = (int)$val;
        if ($val < 0) $val = 0;
      }

      $set[] = "$f = ?";
      $vals[] = $val;
    }
  }

  if (!$set) json_response(['error' => 'No fields to update'], 422);

  $vals[] = $id;

  $pdo = db();
  $stmt = $pdo->prepare("UPDATE shifts SET ".implode(', ', $set)." WHERE id = ?");
  $stmt->execute($vals);

  json_response(['ok' => true]);
}
