<?php
function handle_settings_update(): void {
  $data = get_json_body();
  $pdo = db();
  $current = $pdo->query("SELECT * FROM attendance_settings WHERE id = 1")->fetch();
  if (!$current) {
    $pdo->prepare("INSERT INTO attendance_settings (id, attendance_open, allow_manual_override, ip_restriction_enabled, allowed_ips, device_binding_enabled, updated_at)
                   VALUES (1, 1, 1, 0, '', 0, ?)")->execute([now_dt()]);
  }

  $fields = ['attendance_open','allow_manual_override','ip_restriction_enabled','allowed_ips','device_binding_enabled'];
  $set = [];
  $vals = [];
  foreach ($fields as $f) {
    if (array_key_exists($f, $data)) {
      $set[] = "$f = ?";
      $vals[] = $data[$f];
    }
  }
  if (!$set) json_response(['error' => 'No settings to update'], 422);
  $set[] = "updated_at = ?";
  $vals[] = now_dt();
  $vals[] = 1;

  $stmt = $pdo->prepare("UPDATE attendance_settings SET ".implode(', ', $set)." WHERE id = ?");
  $stmt->execute($vals);

  $actor = $_SESSION['user']['id'] ?? null;
  audit_log($actor ? (int)$actor : null, 'SETTINGS_UPDATE', ['fields' => array_keys($data)]);

  json_response(['ok' => true]);
}
