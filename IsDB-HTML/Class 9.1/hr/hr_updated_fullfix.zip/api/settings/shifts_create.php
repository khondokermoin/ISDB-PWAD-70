<?php
function handle_shifts_create(): void {
  $d = get_json_body();

  $name = trim((string)($d['name'] ?? ''));
  $start = (string)($d['start_time'] ?? '');
  $end   = (string)($d['end_time'] ?? '');
  $grace = (int)($d['grace_minutes'] ?? 0);

  if ($name === '') json_response(['error' => 'Shift name required'], 422);
  if ($start === '' || $end === '') json_response(['error' => 'Start & End required'], 422);

  // basic format validation: HH:MM:SS
  if (!preg_match('/^\d{2}:\d{2}:\d{2}$/', $start)) json_response(['error' => 'start_time must be HH:MM:SS'], 422);
  if (!preg_match('/^\d{2}:\d{2}:\d{2}$/', $end))   json_response(['error' => 'end_time must be HH:MM:SS'], 422);

  if ($grace < 0) $grace = 0;

  $pdo = db();
  $stmt = $pdo->prepare("INSERT INTO shifts (name, start_time, end_time, grace_minutes) VALUES (?, ?, ?, ?)");
  $stmt->execute([$name, $start, $end, $grace]);

  json_response(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
}
