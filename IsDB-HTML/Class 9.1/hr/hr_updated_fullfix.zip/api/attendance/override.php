<?php
function handle_attendance_override(): void {
  $admin = require_admin();
  $d = get_json_body();
  $employee_id = (int)($d['employee_id'] ?? 0);
  $work_date = (string)($d['work_date'] ?? '');
  $reason = trim((string)($d['reason'] ?? ''));

  if ($employee_id <= 0 || $work_date === '' || $reason === '') {
    json_response(['error' => 'employee_id, work_date, reason required'], 422);
  }

  $pdo = db();
  $stmt = $pdo->prepare("SELECT * FROM attendance_logs WHERE employee_id=? AND work_date=? LIMIT 1");
  $stmt->execute([$employee_id, $work_date]);
  $log = $stmt->fetch();

  $fields = ['check_in','check_out','status','note'];
  $set = [];
  $vals = [];
  foreach ($fields as $f) {
    if (array_key_exists($f, $d)) { $set[] = "$f = ?"; $vals[] = $d[$f]; }
  }
  if (!$set) json_response(['error' => 'No fields to override'], 422);

  $set[] = "updated_at = ?";
  $vals[] = now_dt();

  if ($log) {
    $vals[] = (int)$log['id'];
    $pdo->prepare("UPDATE attendance_logs SET ".implode(', ', $set)." WHERE id=?")->execute($vals);
  } else {
    // Insert minimal record with overrides
    $shift_id = $d['shift_id'] ?? null;
    $pdo->prepare("INSERT INTO attendance_logs (employee_id, work_date, shift_id, check_in, check_out, status, note, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
        ->execute([
          $employee_id,
          $work_date,
          $shift_id,
          $d['check_in'] ?? null,
          $d['check_out'] ?? null,
          $d['status'] ?? 'present',
          ($d['note'] ?? '')." | OVERRIDE: ".$reason,
          now_dt(),
          now_dt()
        ]);
  }

  audit_log((int)$admin['id'], 'OVERRIDE_ATTENDANCE', ['employee_id' => $employee_id, 'work_date' => $work_date, 'reason' => $reason]);
  json_response(['ok' => true]);
}
