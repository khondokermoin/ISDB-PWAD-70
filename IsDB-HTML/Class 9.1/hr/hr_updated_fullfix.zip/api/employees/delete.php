<?php
function handle_employees_delete(int $id): void {
  require_admin();
  $pdo = db();

  // Optional safety: attendance থাকলে delete block করতে চাইলে uncomment করুন
  /*
  $st = $pdo->prepare("SELECT COUNT(*) FROM attendance_logs WHERE employee_id = ?");
  $st->execute([$id]);
  if ((int)$st->fetchColumn() > 0) {
    json_response(['error' => 'Cannot delete: employee has attendance records'], 409);
  }
  */

  // delete linked user first (if any)
  $pdo->prepare("DELETE FROM users WHERE employee_id = ?")->execute([$id]);

  // then delete employee
  $pdo->prepare("DELETE FROM employees WHERE id = ?")->execute([$id]);

  audit_log((int)($_SESSION['user_id'] ?? 0), 'DELETE_EMPLOYEE', ['employee_id' => $id]);

  json_response(['ok' => true]);
}
