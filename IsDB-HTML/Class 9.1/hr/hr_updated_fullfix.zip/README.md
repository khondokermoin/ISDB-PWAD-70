# Attendance Web App (Starter) — PHP + MySQL + JS Frontend

## Folder mapping for cPanel
Upload:
- `public/`  -> `public_html/public/`
- `api/`     -> `public_html/api/`
- `database.sql` import into MySQL database
- Copy `api/config.example.php` to `api/config.php` and set DB credentials

## API routing
`/api/.htaccess` routes `/api/...` requests to `api/index.php`.

## First login
- Admin user: `admin`
- Password: `Admin@123`
Change password after first login (you can add UI later).

## Notes
- This is a starter scaffold that already supports:
  - Admin: employee create/activate/deactivate, settings toggle, shifts create
  - Employee: check-in/check-out + monthly report
  - Admin: daily list + monthly summary + CSV export
- Extend modules:
  - Leave requests approval UI
  - Device binding, holiday calendar UI
  - Full shift editor (window/min hours/earliest checkout)
  - Absent auto-mark cron (optional)
