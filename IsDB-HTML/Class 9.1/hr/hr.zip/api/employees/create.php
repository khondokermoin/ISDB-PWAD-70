<?php
function handle_employees_create(): void {
  $data = get_json_body();
  $emp_code = trim((string)($data['emp_code'] ?? ''));
  $name = trim((string)($data['name'] ?? ''));
  $phone = trim((string)($data['phone'] ?? ''));
  $email = trim((string)($data['email'] ?? ''));
  $department = trim((string)($data['department'] ?? ''));
  $designation = trim((string)($data['designation'] ?? ''));
  $join_date = (string)($data['join_date'] ?? date('Y-m-d'));
  $default_shift_id = isset($data['default_shift_id']) ? (int)$data['default_shift_id'] : null;

  // Create login for employee
  $username = trim((string)($data['username'] ?? $emp_code));
  $password = (string)($data['password'] ?? '');

  if ($emp_code === '' || $name === '' || $username === '' || $password === '') {
    json_response(['error' => 'emp_code, name, username, password required'], 422);
  }

  $pdo = db();
  $pdo->beginTransaction();
  try {
    $stmt = $pdo->prepare("INSERT INTO employees (emp_code, name, phone, email, department, designation, join_date, status, default_shift_id, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)");
    $stmt->execute([$emp_code, $name, $phone, $email, $department, $designation, $join_date, $default_shift_id, now_dt()]);
    $employee_id = (int)$pdo->lastInsertId();

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt2 = $pdo->prepare("INSERT INTO users (role, username, email, phone, password_hash, employee_id, is_active, created_at)
                            VALUES ('employee', ?, ?, ?, ?, ?, 1, ?)");
    $stmt2->execute([$username, $email ?: null, $phone ?: null, $hash, $employee_id, now_dt()]);

    $pdo->commit();

    $actor = $_SESSION['user']['id'] ?? null;
    audit_log($actor ? (int)$actor : null, 'CREATE_EMPLOYEE', ['employee_id' => $employee_id, 'emp_code' => $emp_code]);

    json_response(['ok' => true, 'employee_id' => $employee_id], 201);
  } catch (Throwable $e) {
    $pdo->rollBack();
    json_response(['error' => 'Create failed', 'detail' => $e->getMessage()], 400);
  }
}
