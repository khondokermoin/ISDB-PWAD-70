<?php
declare(strict_types=1);

$config = require __DIR__ . '/config.php';

// --- Sessions ---
$secure = (bool)($config['session']['cookie_secure'] ?? true);
$samesite = $config['session']['cookie_samesite'] ?? 'Lax';

session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'domain' => '',
  'secure' => $secure,
  'httponly' => true,
  'samesite' => $samesite,
]);
session_start();

// --- DB ---
function db(): PDO {
  static $pdo = null;
  if ($pdo) return $pdo;

  $config = require __DIR__ . '/config.php';
  $db = $config['db'];
  $dsn = sprintf("mysql:host=%s;dbname=%s;charset=%s", $db['host'], $db['name'], $db['charset'] ?? 'utf8mb4');

  $pdo = new PDO($dsn, $db['user'], $db['pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
  ]);
  return $pdo;
}

// --- Response helpers ---
function json_response($data, int $status = 200): void {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function get_json_body(): array {
  $raw = file_get_contents('php://input') ?: '';
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function method(): string {
  $m = $_SERVER['REQUEST_METHOD'] ?? 'GET';
  // Allow method override from POST
  if ($m === 'POST') {
    $override = $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? ($_POST['_method'] ?? null);
    if ($override) $m = strtoupper((string)$override);
  }
  return strtoupper($m);
}

function require_login(): array {
  if (!isset($_SESSION['user'])) json_response(['error' => 'Unauthorized'], 401);
  return $_SESSION['user'];
}

function require_admin(): array {
  $u = require_login();
  if (($u['role'] ?? '') !== 'admin') json_response(['error' => 'Forbidden'], 403);
  return $u;
}

function now_dt(): string {
  return (new DateTime('now', new DateTimeZone('Asia/Dhaka')))->format('Y-m-d H:i:s');
}

function today_date(): string {
  return (new DateTime('now', new DateTimeZone('Asia/Dhaka')))->format('Y-m-d');
}

function parse_path(): array {
  // Works for /api/index.php/... or /api/...
  $uri = $_SERVER['REQUEST_URI'] ?? '/';
  $qpos = strpos($uri, '?');
  if ($qpos !== false) $uri = substr($uri, 0, $qpos);

  // Normalize to remove leading /api
  $uri = preg_replace('#^/api(?:/index\.php)?#', '', $uri);
  $uri = trim($uri, '/');
  $parts = $uri === '' ? [] : explode('/', $uri);
  return $parts;
}

function audit_log(?int $actor_user_id, string $action, array $meta = []): void {
  try {
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO audit_logs (actor_user_id, action, meta_json, created_at) VALUES (?, ?, ?, ?)");
    $stmt->execute([$actor_user_id, $action, json_encode($meta, JSON_UNESCAPED_UNICODE), now_dt()]);
  } catch (Throwable $e) {
    // Don't block the main flow
  }
}
