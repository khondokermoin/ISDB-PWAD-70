<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

start_session();
migrate();
csrf_init();

if (is_logged_in()) {
    header('Location: /panel');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $u = trim((string)($_POST['username'] ?? ''));
    $p = (string)($_POST['password'] ?? '');

    // ✅ Use central login logic (sets session + updates last_login_at/ip)
    if (attempt_login($u, $p)) {
        session_regenerate_id(true);
        header('Location: /panel');
        exit;
    }

    $error = "Invalid credentials";
}
?>
<!doctype html>
<html lang="en" class="light">
<head>
  <meta charset="utf-8">
  <title>Login - Secure File Server</title>

  <script>
    if (localStorage.theme === "dark") document.documentElement.classList.add("dark");
  </script>

  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white min-h-screen flex items-center justify-center p-6">
  <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow w-full max-w-sm">
    <h1 class="text-xl font-bold mb-4">🔐 Login</h1>

    <?php if ($error): ?>
      <div class="p-3 mb-3 rounded bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200">
        <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
      </div>
    <?php endif; ?>

    <form method="post" class="space-y-3">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
      <input name="username" class="w-full border p-2 rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" placeholder="Username" required>
      <input type="password" name="password" class="w-full border p-2 rounded bg-gray-50 dark:bg-gray-700 dark:border-gray-600" placeholder="Password" required>
      <button class="w-full bg-blue-600 hover:bg-blue-700 text-white p-2 rounded">Login</button>
    </form>

    <p class="text-xs text-gray-500 dark:text-gray-300 mt-3">
      First time? Run <code>/install.php</code> once and then lock it using <code>.htaccess</code>.
    </p>
  </div>
</body>
</html>
