<?php
declare(strict_types=1);

$__PAGE_T0 = microtime(true);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

start_session();
require_login();
migrate();
csrf_init();

$pdo = db();
$me = current_user();
$isAdmin = (($me['role'] ?? '') === 'admin');

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

// ---------- Flash ----------
function flash_add(string $type, string $msg): void {
    $_SESSION['flash'] ??= [];
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}
function flash_take_all(): array {
    $msgs = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $msgs;
}

$FILE_LIMIT = 300; // UI responsiveness

// Helper: detect if "text-ish" by extension
function is_text_ext(string $name): bool {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $textExt = [
        'txt','md','log','ini','conf','cfg','env',
        'py','js','ts','jsx','tsx','php','html','htm','css','scss','less',
        'json','xml','yml','yaml','sh','bat','ps1','sql','csv'
    ];
    return in_array($ext, $textExt, true);
}
function get_ext(string $name): string {
    return strtolower(pathinfo($name, PATHINFO_EXTENSION));
}

function bytes_human(int $bytes): string {
    if ($bytes < 1024) return $bytes . ' B';
    $units = ['KB','MB','GB','TB'];
    $v = (float)$bytes;
    $i = -1;
    do { $v /= 1024; $i++; } while ($v >= 1024 && $i < count($units)-1);
    return rtrim(rtrim(sprintf('%.2f', $v), '0'), '.') . ' ' . $units[$i];
}

// Server-side MIME detection (do not trust client-provided type)
function detect_mime(string $path): string {
    if (!is_file($path)) return 'application/octet-stream';
    $fi = @finfo_open(FILEINFO_MIME_TYPE);
    if (!$fi) return 'application/octet-stream';
    $m = @finfo_file($fi, $path);
    @finfo_close($fi);
    return is_string($m) && $m !== '' ? $m : 'application/octet-stream';
}

function safe_ext(string $name): string {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    // normalize common cases
    if ($ext === 'jpeg') return 'jpg';
    return preg_replace('/[^a-z0-9]/', '', $ext);
}

function validate_upload_or_fail(string $origName, string $tmpPath, int $sizeBytes, bool $isAdmin): array {
    // returns [storedName, originalName, mime, sizeBytes]
    global $BLOCKED_EXTENSIONS, $ALLOWED_EXTENSIONS, $HARD_MAX_UPLOAD_BYTES;

    $origName = trim($origName);
    if ($origName === '') {
        throw new RuntimeException('Invalid filename.');
    }

    // Safety net: hard cap
    if (!empty($HARD_MAX_UPLOAD_BYTES) && $HARD_MAX_UPLOAD_BYTES > 0 && $sizeBytes > $HARD_MAX_UPLOAD_BYTES) {
        throw new RuntimeException('File is too large. Max allowed: ' . bytes_human((int)$HARD_MAX_UPLOAD_BYTES));
    }

    $ext = safe_ext($origName);
    if ($ext !== '' && in_array($ext, $BLOCKED_EXTENSIONS, true)) {
        throw new RuntimeException('File type is not allowed.');
    }

    // Default allowlist (applies to everyone, including admin, unless you expand list)
    if ($ext !== '' && !in_array($ext, $ALLOWED_EXTENSIONS, true)) {
        // Admin can still upload unknown types ONLY if there is no extension
        // (prevents .php etc). You can change policy by expanding $ALLOWED_EXTENSIONS.
        throw new RuntimeException('Unsupported file extension: .' . $ext);
    }

    $mime = detect_mime($tmpPath);

    // Stored name
    $stored = bin2hex(random_bytes(16)) . ($ext ? ('.' . $ext) : '');
    return [$stored, $origName, $mime, $sizeBytes];
}

function scan_file_status(string $path): string {
    // Returns: clean | infected | skipped
    // Shared hosting may not have clamscan.
    $which = trim((string)@shell_exec('command -v clamscan 2>/dev/null'));
    if ($which === '') return 'skipped';

    // Run once (older versions ran clamscan twice, doubling CPU time)
    $cmd = 'clamscan --no-summary ' . escapeshellarg($path);
    $rc = 2;
    @exec($cmd . ' 2>/dev/null', $dummy, $rc);

    // clamscan exit codes: 0 clean, 1 infected, 2 error
    if ($rc === 0) return 'clean';
    if ($rc === 1) return 'infected';
    return 'skipped';
}

function user_used_bytes(PDO $pdo, int $userId): int {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(size_bytes),0) AS s FROM files WHERE uploaded_by=:u");
    $stmt->execute([':u'=>$userId]);
    $a = (int)($stmt->fetch()['s'] ?? 0);
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(size_bytes),0) AS s FROM pending_uploads WHERE uploaded_by=:u");
    $stmt->execute([':u'=>$userId]);
    $b = (int)($stmt->fetch()['s'] ?? 0);
    return $a + $b;
}

// Clean URL base
$PANEL_BASE = '/panel';

// ---------- ACTIONS ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $action = $_POST['action'] ?? '';

    if ($isAdmin && $action === 'create_user') {
        $username = trim((string)($_POST['new_username'] ?? ''));
        $password = (string)($_POST['new_password'] ?? '');

        $canUpload = isset($_POST['new_can_upload']) ? 1 : 0;
        $canView = isset($_POST['new_can_view']) ? 1 : 0;
        $canDl = isset($_POST['new_can_download']) ? 1 : 0;

        $quotaVal = (int)($_POST['new_quota_value'] ?? 0);
        $quotaUnit = (string)($_POST['new_quota_unit'] ?? 'MB');
        $quotaBytes = 0;
        if ($quotaVal > 0) {
            if ($quotaUnit === 'KB') $quotaBytes = $quotaVal * 1024;
            elseif ($quotaUnit === 'GB') $quotaBytes = $quotaVal * 1024*1024*1024;
            else $quotaBytes = $quotaVal * 1024*1024;
        }

        $maxVal = (int)($_POST['new_max_value'] ?? 0);
        $maxUnit = (string)($_POST['new_max_unit'] ?? 'MB');
        $maxBytes = 0;
        if ($maxVal > 0) {
            if ($maxUnit === 'KB') $maxBytes = $maxVal * 1024;
            elseif ($maxUnit === 'GB') $maxBytes = $maxVal * 1024*1024*1024;
            else $maxBytes = $maxVal * 1024*1024;
        }

        if ($username === '' || strlen($password) < 8) {
            flash_add('error', 'Username required and password must be at least 8 characters.');
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, pass_hash, role, can_upload, can_view, can_download, upload_quota_bytes, max_file_bytes) VALUES (:u,:h,'user',:cu,:cv,:cd,:qb,:mb)");
            try {
                $stmt->execute([':u'=>$username, ':h'=>$hash, ':cu'=>$canUpload, ':cv'=>$canView, ':cd'=>$canDl, ':qb'=>$quotaBytes, ':mb'=>$maxBytes]);
                flash_add('success', 'User created successfully.');
            } catch (Throwable $e) {
                flash_add('error', 'Username already exists.');
            }
        }
        header('Location: ' . $PANEL_BASE);
        exit;
    }

    if ($isAdmin && $action === 'upload') {
        if (empty($_FILES['file']['name'])) {
            flash_add('error', 'No file selected.');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        $orig = (string)$_FILES['file']['name'];
        $tmp  = (string)$_FILES['file']['tmp_name'];
        $size = (int)($_FILES['file']['size'] ?? 0);

        try {
            [$stored, $origSafe, $mime, $sizeSafe] = validate_upload_or_fail($orig, $tmp, $size, true);
        } catch (Throwable $e) {
            flash_add('error', $e->getMessage());
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        $dest = $FILES_DIR . DIRECTORY_SEPARATOR . $stored;

        if (!is_uploaded_file($tmp)) {
            flash_add('error', 'Upload failed (not a valid uploaded file).');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        if (!@move_uploaded_file($tmp, $dest)) {
            flash_add('error', 'Upload failed (cannot move file).');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO files (original_name, stored_name, mime, size_bytes, uploaded_by)
            VALUES (:o,:s,:m,:b,:u)
        ");
        $stmt->execute([':o'=>$origSafe, ':s'=>$stored, ':m'=>$mime, ':b'=>$sizeSafe, ':u'=>$me['id']]);
        flash_add('success', 'File uploaded successfully.');

        header('Location: ' . $PANEL_BASE . '/files');
        exit;
    }

    if (!$isAdmin && $action === 'user_upload') {
        // User uploads go to pending queue for admin review.
        if (!user_can_upload($me)) {
            flash_add('error', 'Upload is disabled for your account.');
            header('Location: ' . $PANEL_BASE);
            exit;
        }
        if (empty($_FILES['file']['name'])) {
            flash_add('error', 'No file selected.');
            header('Location: ' . $PANEL_BASE);
            exit;
        }

        $orig = (string)$_FILES['file']['name'];
        $tmp  = (string)$_FILES['file']['tmp_name'];
        $size = (int)($_FILES['file']['size'] ?? 0);
        $ip   = get_client_ip();

        if (!is_uploaded_file($tmp)) {
            flash_add('error', 'Upload failed (not a valid uploaded file).');
            header('Location: ' . $PANEL_BASE);
            exit;
        }

        // Per-file limit
        $maxFile = (int)($me['max_file_bytes'] ?? 0);
        if ($maxFile > 0 && $size > $maxFile) {
            flash_add('error', 'File is too large. Max allowed: ' . bytes_human($maxFile));
            header('Location: ' . $PANEL_BASE);
            exit;
        }

        // Total quota
        $quota = (int)($me['upload_quota_bytes'] ?? 0);
        if ($quota > 0) {
            $used = user_used_bytes($pdo, (int)$me['id']);
            if ($used + $size > $quota) {
                flash_add('error', 'Upload quota exceeded. Used ' . bytes_human($used) . ' / ' . bytes_human($quota));
                header('Location: ' . $PANEL_BASE);
                exit;
            }
        }

        // Validate + generate safe temp name
        try {
            [$tempName, $origSafe, $mime, $sizeSafe] = validate_upload_or_fail($orig, $tmp, $size, false);
        } catch (Throwable $e) {
            flash_add('error', $e->getMessage());
            header('Location: ' . $PANEL_BASE);
            exit;
        }
        $dest = $PENDING_DIR . DIRECTORY_SEPARATOR . $tempName;

        if (!@move_uploaded_file($tmp, $dest)) {
            flash_add('error', 'Upload failed (cannot move file).');
            header('Location: ' . $PANEL_BASE);
            exit;
        }

        $scan = scan_file_status($dest);
        if ($scan === 'infected') {
            @unlink($dest);
            flash_add('error', 'Upload rejected: virus detected.');
            header('Location: ' . $PANEL_BASE);
            exit;
        }

        $stmt = $pdo->prepare("INSERT INTO pending_uploads (original_name, temp_name, mime, size_bytes, uploaded_by, ip_address, scan_status) VALUES (:o,:t,:m,:b,:u,:ip,:st)");
        $stmt->execute([':o'=>$origSafe, ':t'=>$tempName, ':m'=>$mime, ':b'=>$sizeSafe, ':u'=>$me['id'], ':ip'=>$ip, ':st'=>$scan]);
        flash_add('success', 'File submitted for admin review.');
        header('Location: ' . $PANEL_BASE);
        exit;
    }

    if ($isAdmin && $action === 'create_text_file') {
        $filename = trim((string)($_POST['filename'] ?? ''));
        $content  = (string)($_POST['content'] ?? '');

        if ($filename === '') {
            flash_add('error', 'Filename cannot be empty.');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        // sanitize filename (very basic)
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
        if ($filename === '' || $filename === '.' || $filename === '..') {
            flash_add('error', 'Invalid filename.');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        // Enforce safe extensions (prevent creating executable files like .php)
        global $BLOCKED_EXTENSIONS, $ALLOWED_EXTENSIONS;

        $ext = safe_ext($filename);
        if ($ext !== '' && in_array($ext, $BLOCKED_EXTENSIONS, true)) {
            flash_add('error', 'File type is not allowed.');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        // Creating a file from the UI is meant for text content only.
        if ($ext === '' || !is_text_ext($filename) || !in_array($ext, $ALLOWED_EXTENSIONS, true)) {
            flash_add('error', 'Only safe text formats are allowed (e.g. .txt, .md, .csv, .json).');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }
        $stored = bin2hex(random_bytes(16)) . ($ext ? ('.' . $ext) : '');
        $dest = $FILES_DIR . DIRECTORY_SEPARATOR . $stored;

        $bytes = @file_put_contents($dest, $content);
        if ($bytes === false) {
            flash_add('error', 'Failed to create file on disk.');
            header('Location: ' . $PANEL_BASE . '/files');
            exit;
        }

        $mime = detect_mime($dest);
        $stmt = $pdo->prepare("
            INSERT INTO files (original_name, stored_name, mime, size_bytes, uploaded_by)
            VALUES (:o,:s,:m,:b,:u)
        ");
        $stmt->execute([':o'=>$filename, ':s'=>$stored, ':m'=>$mime, ':b'=>(int)$bytes, ':u'=>$me['id']]);

        flash_add('success', 'New file created successfully.');
        header('Location: ' . $PANEL_BASE . '/files');
        exit;
    }

    if ($isAdmin && $action === 'save_perms') {
        $userId = (int)($_POST['perm_user_id'] ?? 0);
        $allowView = $_POST['allow_view'] ?? [];
        $allowDl = $_POST['allow_download'] ?? [];

        if ($userId <= 0) {
            flash_add('error', 'Please select a user.');
            header('Location: ' . $PANEL_BASE . '/perms');
            exit;
        }

        $pdo->beginTransaction();
        $pdo->prepare("DELETE FROM permissions WHERE user_id=:uid")->execute([':uid'=>$userId]);

        $stmtIns = $pdo->prepare("INSERT INTO permissions (user_id, file_id, can_view, can_download) VALUES (:uid,:fid,:v,:d)");
        $allIds = array_unique(array_merge(array_keys($allowView), array_keys($allowDl)));
        foreach ($allIds as $fileIdStr) {
            $fid = (int)$fileIdStr;
            if ($fid <= 0) continue;
            $v = isset($allowView[$fileIdStr]) ? 1 : 0;
            $d = isset($allowDl[$fileIdStr]) ? 1 : 0;
            // if download is allowed, view should be allowed too
            if ($d === 1) $v = 1;
            if ($v === 1) {
                $stmtIns->execute([':uid'=>$userId, ':fid'=>$fid, ':v'=>$v, ':d'=>$d]);
            }
        }
        $pdo->commit();

        flash_add('success', 'Permissions saved.');
        header('Location: ' . $PANEL_BASE . '/perms?user=' . $userId);
        exit;
    }

    if ($isAdmin && $action === 'approve_pending') {
        $pid = (int)($_POST['pending_id'] ?? 0);
        if ($pid <= 0) {
            flash_add('error', 'Bad request.');
            header('Location: ' . $PANEL_BASE . '/pending');
            exit;
        }

        // Load pending
        $stmt = $pdo->prepare("SELECT p.*, u.username FROM pending_uploads p JOIN users u ON u.id=p.uploaded_by WHERE p.id=:id");
        $stmt->execute([':id'=>$pid]);
        $p = $stmt->fetch();
        if (!$p) {
            flash_add('error', 'Pending upload not found.');
            header('Location: ' . $PANEL_BASE . '/pending');
            exit;
        }

        // Move file to final storage (re-validate extension)
        global $BLOCKED_EXTENSIONS, $ALLOWED_EXTENSIONS;
        $ext = safe_ext((string)$p['original_name']);
        if ($ext !== '' && (in_array($ext, $BLOCKED_EXTENSIONS, true) || !in_array($ext, $ALLOWED_EXTENSIONS, true))) {
            // Remove pending file + row if the type is no longer allowed
            $src = $PENDING_DIR . DIRECTORY_SEPARATOR . (string)$p['temp_name'];
            @unlink($src);
            $pdo->prepare("DELETE FROM pending_uploads WHERE id=:id")->execute([':id'=>$pid]);
            flash_add('error', 'Rejected: unsupported file type.');
            header('Location: ' . $PANEL_BASE . '/pending');
            exit;
        }

        $stored = bin2hex(random_bytes(16)) . ($ext ? ('.' . $ext) : '');
        $src = $PENDING_DIR . DIRECTORY_SEPARATOR . (string)$p['temp_name'];
        $dst = $FILES_DIR . DIRECTORY_SEPARATOR . $stored;

        if (!is_file($src)) {
            // cleanup DB row if file missing
            $pdo->prepare("DELETE FROM pending_uploads WHERE id=:id")->execute([':id'=>$pid]);
            flash_add('error', 'Pending file missing on disk.');
            header('Location: ' . $PANEL_BASE . '/pending');
            exit;
        }

        if (!@rename($src, $dst)) {
            flash_add('error', 'Failed to finalize file (cannot move).');
            header('Location: ' . $PANEL_BASE . '/pending');
            exit;
        }

        // Detect MIME + size from the finalized file (do not trust client)
        $finalMime = detect_mime($dst);
        $finalSize = (int)@filesize($dst);

        // Insert into files and grant uploader access by default
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO files (original_name, stored_name, mime, size_bytes, uploaded_by, ip_address, scan_status, approved_by, approved_at) VALUES (:o,:s,:m,:b,:u,:ip,:st,:ab,datetime('now'))");
        $stmt->execute([
            ':o'=>(string)$p['original_name'],
            ':s'=>$stored,
            ':m'=>$finalMime,
            ':b'=>$finalSize,
            ':u'=>(int)$p['uploaded_by'],
            ':ip'=>(string)($p['ip_address'] ?? ''),
            ':st'=>(string)($p['scan_status'] ?? 'pending'),
            ':ab'=>(int)$me['id'],
        ]);
        $newFileId = (int)$pdo->lastInsertId();

        // Give uploader view+download (admin can change later)
        $pdo->prepare("INSERT OR REPLACE INTO permissions (user_id, file_id, can_view, can_download) VALUES (:u,:f,1,1)")
            ->execute([':u'=>(int)$p['uploaded_by'], ':f'=>$newFileId]);

        $pdo->prepare("DELETE FROM pending_uploads WHERE id=:id")->execute([':id'=>$pid]);
        $pdo->commit();

        flash_add('success', 'Approved: ' . (string)$p['original_name']);
        header('Location: ' . $PANEL_BASE . '/pending');
        exit;
    }

    if ($isAdmin && $action === 'reject_pending') {
        $pid = (int)($_POST['pending_id'] ?? 0);
        if ($pid <= 0) {
            flash_add('error', 'Bad request.');
            header('Location: ' . $PANEL_BASE . '/pending');
            exit;
        }
        $stmt = $pdo->prepare("SELECT * FROM pending_uploads WHERE id=:id");
        $stmt->execute([':id'=>$pid]);
        $p = $stmt->fetch();
        if ($p) {
            $src = $PENDING_DIR . DIRECTORY_SEPARATOR . (string)$p['temp_name'];
            @unlink($src);
            $pdo->prepare("DELETE FROM pending_uploads WHERE id=:id")->execute([':id'=>$pid]);
        }
        flash_add('success', 'Pending upload rejected.');
        header('Location: ' . $PANEL_BASE . '/pending');
        exit;
    }

    if ($isAdmin && $action === 'update_user') {
        $uid = (int)($_POST['user_id'] ?? 0);
        if ($uid <= 0) {
            flash_add('error', 'Bad request.');
            header('Location: ' . $PANEL_BASE . '/users');
            exit;
        }

        $canUpload = isset($_POST['can_upload']) ? 1 : 0;
        $canView = isset($_POST['can_view']) ? 1 : 0;
        $canDl = isset($_POST['can_download']) ? 1 : 0;

        $quotaVal = (int)($_POST['quota_value'] ?? 0);
        $quotaUnit = (string)($_POST['quota_unit'] ?? 'MB');
        $quotaBytes = 0;
        if ($quotaVal > 0) {
            $mul = 1024;
            if ($quotaUnit === 'KB') $mul = 1024;
            elseif ($quotaUnit === 'MB') $mul = 1024*1024;
            elseif ($quotaUnit === 'GB') $mul = 1024*1024*1024;
            $quotaBytes = $quotaVal * $mul;
        }

        $maxVal = (int)($_POST['max_value'] ?? 0);
        $maxUnit = (string)($_POST['max_unit'] ?? 'MB');
        $maxBytes = 0;
        if ($maxVal > 0) {
            $mul = 1024;
            if ($maxUnit === 'KB') $mul = 1024;
            elseif ($maxUnit === 'MB') $mul = 1024*1024;
            elseif ($maxUnit === 'GB') $mul = 1024*1024*1024;
            $maxBytes = $maxVal * $mul;
        }

        $stmt = $pdo->prepare("UPDATE users SET can_upload=:cu, can_view=:cv, can_download=:cd, upload_quota_bytes=:qb, max_file_bytes=:mb WHERE id=:id AND role='user'");
        $stmt->execute([':cu'=>$canUpload, ':cv'=>$canView, ':cd'=>$canDl, ':qb'=>$quotaBytes, ':mb'=>$maxBytes, ':id'=>$uid]);
        flash_add('success', 'User settings updated.');
        header('Location: ' . $PANEL_BASE . '/users');
        exit;
    }

    if ($isAdmin && $action === 'delete_user') {
        $uid = (int)($_POST['user_id'] ?? 0);
        if ($uid <= 0) {
            flash_add('error', 'Bad request.');
            header('Location: ' . $PANEL_BASE . '/users');
            exit;
        }
        // Do not delete admin accounts
        $stmt = $pdo->prepare("SELECT id, role FROM users WHERE id=:id");
        $stmt->execute([':id'=>$uid]);
        $u = $stmt->fetch();
        if (!$u || (string)$u['role'] !== 'user') {
            flash_add('error', 'Only user accounts can be deleted.');
            header('Location: ' . $PANEL_BASE . '/users');
            exit;
        }
        $pdo->beginTransaction();
        $pdo->prepare("DELETE FROM permissions WHERE user_id=:uid")->execute([':uid'=>$uid]);
        // keep files but detach ownership
        $pdo->prepare("UPDATE files SET uploaded_by=NULL WHERE uploaded_by=:uid")->execute([':uid'=>$uid]);
        $pdo->prepare("DELETE FROM pending_uploads WHERE uploaded_by=:uid")->execute([':uid'=>$uid]);
        $pdo->prepare("DELETE FROM users WHERE id=:uid AND role='user'")->execute([':uid'=>$uid]);
        $pdo->commit();
        flash_add('success', 'User deleted.');
        header('Location: ' . $PANEL_BASE . '/users');
        exit;
    }

    flash_add('error', 'Invalid action.');
    header('Location: ' . $PANEL_BASE);
    exit;
}

// ---------- TAB ----------
$tab = $_GET['tab'] ?? ($isAdmin ? 'files' : 'myfiles');
if (!$isAdmin) $tab = 'myfiles';

// ---------- DATA LOAD ----------
$files = [];
if ($isAdmin) {
    $stmt = $pdo->prepare("
      SELECT f.id, f.original_name, f.size_bytes, f.uploaded_at, f.mime,
             f.ip_address, f.scan_status,
             u.username AS uploaded_by_user
      FROM files f
      LEFT JOIN users u ON u.id = f.uploaded_by
      ORDER BY f.id DESC LIMIT :lim
    ");
    $stmt->bindValue(':lim', $FILE_LIMIT, PDO::PARAM_INT);
    $stmt->execute();
    $files = $stmt->fetchAll();
}

$pending = [];
if ($isAdmin) {
    $stmt = $pdo->prepare("
      SELECT p.id, p.original_name, p.size_bytes, p.uploaded_at, p.ip_address, p.scan_status,
             u.username AS uploaded_by_user
      FROM pending_uploads p
      JOIN users u ON u.id = p.uploaded_by
      ORDER BY p.id DESC LIMIT :lim
    ");
    $stmt->bindValue(':lim', $FILE_LIMIT, PDO::PARAM_INT);
    $stmt->execute();
    $pending = $stmt->fetchAll();
}

$users = [];
if ($isAdmin && $tab === 'perms') {
    $users = $pdo->query("SELECT id, username, role FROM users ORDER BY username ASC")->fetchAll();
}

$userIdForPerm = (int)($_GET['user'] ?? 0);
$permMap = [];
if ($isAdmin && $tab === 'perms' && $userIdForPerm > 0) {
    $stmt = $pdo->prepare("SELECT file_id, can_view, can_download FROM permissions WHERE user_id=:uid");
    $stmt->execute([':uid'=>$userIdForPerm]);
    foreach ($stmt->fetchAll() as $r) {
        $permMap[(int)$r['file_id']] = ['v'=>(int)($r['can_view']??0), 'd'=>(int)($r['can_download']??0)];
    }
}

$myAllowed = [];
if (!$isAdmin) {
    if (!user_can_view($me)) {
        $myAllowed = [];
    } else {
    $stmt = $pdo->prepare("
      SELECT f.id, f.original_name, f.size_bytes, f.uploaded_at, f.mime, p.can_download
      FROM permissions p
      JOIN files f ON f.id = p.file_id
      WHERE p.user_id = :uid AND p.can_view=1
      ORDER BY f.id DESC
      LIMIT :lim
    ");
    $stmt->bindValue(':uid', (int)$me['id'], PDO::PARAM_INT);
    $stmt->bindValue(':lim', $FILE_LIMIT, PDO::PARAM_INT);
    $stmt->execute();
    $myAllowed = $stmt->fetchAll();
    }
}

$flash = flash_take_all();
?>
<!doctype html>
<html lang="en" class="light">
<head>
  <meta charset="utf-8">
  <title><?php echo h($APP_NAME); ?></title>

  <script>
    if (localStorage.theme === "dark" || (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
      document.documentElement.classList.add("dark");
    } else { document.documentElement.classList.remove("dark"); }
  </script>

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    body {
      --c1: #f0f4f8; --c2: #d9e2ec; --c3: #bcccdc; --c4: #9fb3c8;
      background: linear-gradient(-45deg, var(--c1), var(--c2), var(--c3), var(--c4));
      background-size: 400% 400%; animation: gradient-animation 20s ease infinite; transition: background 0.5s ease;
    }
    html.dark body { --c1: #1a202c; --c2: #2d3748; --c3: #4a5568; --c4: #2d3748; }
    @keyframes gradient-animation { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
    #modal-content img, #modal-content iframe, #modal-content video, #modal-content audio { max-width: 100%; max-height: 100%; margin: auto; }
    .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
  </style>
</head>

<body class="text-gray-900 dark:text-white min-h-screen flex flex-col">

<header class="bg-black bg-opacity-20 backdrop-blur-sm text-white p-4 flex justify-between items-center shadow-md">
  <div>
    <h1 class="text-xl font-semibold">📁 File Manager for <?php echo h((string)($me['username'] ?? '')); ?></h1>
  </div>
  <div class="flex items-center gap-4">
    <button onclick="toggleTheme()" class="bg-gray-100 text-gray-900 dark:bg-gray-700 dark:text-white w-10 h-8 rounded-md text-sm shadow hover:bg-opacity-80 transition" aria-label="Toggle Theme">
      <i class="fas fa-sun dark:hidden"></i><i class="fas fa-moon hidden dark:inline"></i>
    </button>
    <a href="/logout.php" class="bg-gray-100 text-gray-900 dark:bg-gray-700 dark:text-white px-3 py-1 rounded-md text-sm shadow hover:bg-opacity-80 transition flex items-center gap-2" aria-label="Logout">
      <i class="fas fa-sign-out-alt"></i> Logout
    </a>
  </div>
</header>

<main class="container mx-auto p-4 flex-grow">

  <?php if ($flash): ?>
    <?php foreach ($flash as $m): ?>
      <?php $ok = ($m['type'] ?? '') === 'success'; ?>
      <div class="p-4 mb-4 text-sm rounded-lg <?php echo $ok
        ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'
        : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'; ?>">
        <?php echo h((string)($m['msg'] ?? '')); ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

  <?php if (!$isAdmin): ?>
    <!-- USER VIEW -->
    <div class="bg-white bg-opacity-60 dark:bg-gray-800 dark:bg-opacity-60 backdrop-blur-md p-6 rounded-lg shadow-lg">
      <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 border-b dark:border-gray-700 pb-2 mb-2">
        <h2 class="text-lg font-bold">📂 My Files</h2>
        <div class="text-xs text-gray-600 dark:text-gray-300">
          <?php
            $quota = (int)($me['upload_quota_bytes'] ?? 0);
            $used = user_used_bytes($pdo, (int)$me['id']);
            if ($quota > 0) echo 'Quota: ' . h(bytes_human($used)) . ' / ' . h(bytes_human($quota));
          ?>
        </div>
        <div class="flex items-center gap-3">
          <div class="relative">
            <input type="text" id="search-input" placeholder="Search files..." class="w-full max-w-xs p-2 pl-10 text-sm rounded-md bg-gray-50 dark:bg-gray-700 border border-transparent focus:border-blue-500 focus:ring-0">
            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          </div>
          <div class="flex items-center gap-2 text-sm">
            <button id="sort-az" class="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition" aria-label="Sort A to Z">A-Z</button>
            <button id="sort-za" class="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition" aria-label="Sort Z to A">Z-A</button>
          </div>
        </div>
      </div>

      <?php if (user_can_upload($me)): ?>
        <div class="mb-4 p-3 rounded bg-black/5 dark:bg-white/5">
          <div class="font-semibold mb-2">📤 Upload (Admin review required)</div>
          <form method="post" enctype="multipart/form-data" class="flex flex-col sm:flex-row gap-2 items-start sm:items-center">
            <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
            <input type="hidden" name="action" value="user_upload">
            <input type="file" name="file" required class="block w-full p-2 bg-gray-50 dark:bg-gray-700 rounded" />
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow transition">Submit</button>
          </form>
          <?php if ((int)($me['max_file_bytes'] ?? 0) > 0): ?>
            <div class="text-xs text-gray-500 mt-1">Max per file: <?php echo h(bytes_human((int)$me['max_file_bytes'])); ?></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <ul id="file-list" class="space-y-1">
        <?php if (!$myAllowed): ?>
          <li class="text-sm text-gray-600 dark:text-gray-300">No files assigned yet.</li>
        <?php else: ?>
          <?php foreach ($myAllowed as $f): $name=(string)$f['original_name']; $ext=get_ext($name); ?>
            <li class="file-item flex justify-between items-center gap-4 p-2 rounded-md transition-colors duration-150 odd:bg-black/5 dark:odd:bg-white/5 hover:bg-blue-100 dark:hover:bg-blue-900/40"
                data-filename="<?php echo h(mb_strtolower($name)); ?>">
              <div class="min-w-0">
                <div class="truncate font-medium" title="<?php echo h($name); ?>"><?php echo h($name); ?></div>
                <div class="text-xs text-gray-500"><?php echo h((string)$f['uploaded_at']); ?> • <?php echo (int)$f['size_bytes']; ?> bytes</div>
              </div>
              <div class="flex items-center gap-2 flex-shrink-0">
                <button type="button"
                        class="view-button bg-green-500 hover:bg-green-600 text-white w-8 h-8 flex items-center justify-center rounded-md text-sm shadow transition"
                        data-id="<?php echo (int)$f['id']; ?>"
                        data-filename="<?php echo h($name); ?>"
                        data-ext="<?php echo h($ext); ?>"
                        data-text="<?php echo is_text_ext($name) ? '1' : '0'; ?>"
                        aria-label="View"><i class="fas fa-eye"></i></button>

                <?php if (user_can_download($me) && (int)($f['can_download'] ?? 0) === 1): ?>
                  <a href="/file/<?php echo (int)$f['id']; ?>"
                     class="bg-blue-600 hover:bg-blue-700 text-white w-8 h-8 flex items-center justify-center rounded-md text-sm shadow transition"
                     aria-label="Download"><i class="fas fa-download"></i></a>
                <?php else: ?>
                  <span class="bg-gray-300 dark:bg-gray-700 text-gray-600 dark:text-gray-300 w-8 h-8 flex items-center justify-center rounded-md text-sm" title="Download not allowed"><i class="fas fa-ban"></i></span>
                <?php endif; ?>
              </div>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>

  <?php else: ?>
    <!-- ADMIN VIEW TOP -->
    <div class="grid md:grid-cols-2 gap-6 mb-6">

      <div class="bg-white bg-opacity-60 dark:bg-gray-800 dark:bg-opacity-60 backdrop-blur-md p-6 rounded-lg shadow-lg">
        <h2 class="text-lg font-bold mb-2">👤 Create User</h2>
        <form method="post" class="space-y-2">
          <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
          <input type="hidden" name="action" value="create_user">
          <input name="new_username" placeholder="username" class="block w-full mb-2 p-2 bg-gray-50 dark:bg-gray-700 rounded" required>
          <input type="password" name="new_password" placeholder="password (min 8)" class="block w-full mb-2 p-2 bg-gray-50 dark:bg-gray-700 rounded" required>
          <div class="p-2 rounded bg-black/5 dark:bg-white/5">
            <div class="text-sm font-medium mb-1">Capabilities</div>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="new_can_upload"> Upload</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="new_can_view" checked> View list</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="new_can_download" checked> Download</label>
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div>
              <div class="text-xs text-gray-600 dark:text-gray-300 mb-1">Total quota (0 = unlimited)</div>
              <div class="flex gap-2">
                <input name="new_quota_value" type="number" min="0" class="w-full p-2 rounded bg-gray-50 dark:bg-gray-700" value="0">
                <select name="new_quota_unit" class="p-2 rounded bg-gray-50 dark:bg-gray-700">
                  <option value="KB">KB</option>
                  <option value="MB" selected>MB</option>
                  <option value="GB">GB</option>
                </select>
              </div>
            </div>
            <div>
              <div class="text-xs text-gray-600 dark:text-gray-300 mb-1">Max per file (0 = unlimited)</div>
              <div class="flex gap-2">
                <input name="new_max_value" type="number" min="0" class="w-full p-2 rounded bg-gray-50 dark:bg-gray-700" value="0">
                <select name="new_max_unit" class="p-2 rounded bg-gray-50 dark:bg-gray-700">
                  <option value="KB">KB</option>
                  <option value="MB" selected>MB</option>
                  <option value="GB">GB</option>
                </select>
              </div>
            </div>
          </div>
          <button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md shadow transition">Create</button>
        </form>
      </div>

      <div class="bg-white bg-opacity-60 dark:bg-gray-800 dark:bg-opacity-60 backdrop-blur-md p-6 rounded-lg shadow-lg">
        <h2 class="text-lg font-bold mb-2">📤 Upload File</h2>
        <form method="post" enctype="multipart/form-data">
          <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
          <input type="hidden" name="action" value="upload">
          <input type="file" name="file" required class="block w-full mb-2 p-2 bg-gray-50 dark:bg-gray-700 rounded"/>
          <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow transition">Upload</button>
        </form>
        <p class="text-xs text-gray-500 mt-2">Large files may be slow on shared hosting.</p>
      </div>
    </div>

    <!-- Create New File -->
    <div class="bg-white bg-opacity-60 dark:bg-gray-800 dark:bg-opacity-60 backdrop-blur-md p-6 rounded-lg shadow-lg mb-6">
      <h2 class="text-lg font-bold mb-2">📝 Create New File</h2>
      <form method="post" class="space-y-2">
        <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
        <input type="hidden" name="action" value="create_text_file">
        <input name="filename" placeholder="example.txt / notes.md / data.csv / config.json"
               class="block w-full mb-2 p-2 bg-gray-50 dark:bg-gray-700 rounded" required>
        <textarea name="content" rows="7" placeholder="Write text content here..."
                  class="block w-full mb-2 p-2 bg-gray-50 dark:bg-gray-700 rounded resize-none mono"></textarea>
        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md shadow transition">Create</button>
      </form>
    </div>

    <!-- Files / Permissions -->
    <div class="bg-white bg-opacity-60 dark:bg-gray-800 dark:bg-opacity-60 backdrop-blur-md p-6 rounded-lg shadow-lg">
      <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 border-b dark:border-gray-700 pb-2 mb-2">
        <div class="flex items-center gap-4">
          <a class="<?php echo $tab==='files'?'font-bold underline':''; ?>" href="<?php echo $PANEL_BASE; ?>/files">📂 Files</a>
          <a class="<?php echo $tab==='pending'?'font-bold underline':''; ?>" href="<?php echo $PANEL_BASE; ?>/pending">🕵️ Pending</a>
          <a class="<?php echo $tab==='perms'?'font-bold underline':''; ?>" href="<?php echo $PANEL_BASE; ?>/perms">🔐 Permissions</a>
          <a class="<?php echo $tab==='users'?'font-bold underline':''; ?>" href="<?php echo $PANEL_BASE; ?>/users">👥 Users</a>
        </div>

        <?php if ($tab === 'files'): ?>
        <div class="flex items-center gap-3">
          <div class="relative">
            <input type="text" id="search-input" placeholder="Search files..." class="w-full max-w-xs p-2 pl-10 text-sm rounded-md bg-gray-50 dark:bg-gray-700 border border-transparent focus:border-blue-500 focus:ring-0">
            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          </div>
          <div class="flex items-center gap-2 text-sm">
            <button id="sort-az" class="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition" aria-label="Sort A to Z">A-Z</button>
            <button id="sort-za" class="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition" aria-label="Sort Z to A">Z-A</button>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <?php if ($tab === 'files'): ?>
        <ul id="file-list" class="space-y-1">
          <?php if (!$files): ?>
            <li class="text-sm text-gray-700 dark:text-gray-300">No files uploaded yet.</li>
          <?php else: ?>
            <?php foreach ($files as $f): $name=(string)$f['original_name']; $ext=get_ext($name); ?>
              <li class="file-item flex justify-between items-center gap-4 p-2 rounded-md transition-colors duration-150 odd:bg-black/5 dark:odd:bg-white/5 hover:bg-blue-100 dark:hover:bg-blue-900/40"
                  data-filename="<?php echo h(mb_strtolower($name)); ?>">
                <div class="min-w-0">
                  <div class="truncate font-medium" title="<?php echo h($name); ?>"><?php echo h($name); ?></div>
                  <div class="text-xs text-gray-500">
                    <?php echo h((string)$f['uploaded_at']); ?> • <?php echo (int)$f['size_bytes']; ?> bytes
                    <?php if (!empty($f['uploaded_by_user'])): ?> • by <?php echo h((string)$f['uploaded_by_user']); ?><?php endif; ?>
                    <?php if (!empty($f['ip_address'])): ?> • IP <?php echo h((string)$f['ip_address']); ?><?php endif; ?>
                    <?php if (!empty($f['scan_status'])): ?> • scan: <?php echo h((string)$f['scan_status']); ?><?php endif; ?>
                  </div>
                </div>

                <div class="flex items-center gap-2 flex-shrink-0">
                  <button type="button"
                          class="view-button bg-green-500 hover:bg-green-600 text-white w-8 h-8 flex items-center justify-center rounded-md text-sm shadow transition"
                          data-id="<?php echo (int)$f['id']; ?>"
                          data-filename="<?php echo h($name); ?>"
                          data-ext="<?php echo h($ext); ?>"
                          data-text="<?php echo is_text_ext($name) ? '1' : '0'; ?>"
                          aria-label="View"><i class="fas fa-eye"></i></button>

                  <a href="/file/<?php echo (int)$f['id']; ?>"
                     class="bg-blue-600 hover:bg-blue-700 text-white w-8 h-8 flex items-center justify-center rounded-md text-sm shadow transition"
                     aria-label="Download"><i class="fas fa-download"></i></a>

                  <form method="post" action="/delete.php" class="m-0" onsubmit="return confirm('Delete <?php echo h($name); ?>?')">
                    <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
                    <input type="hidden" name="id" value="<?php echo (int)$f['id']; ?>">
                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white w-8 h-8 flex items-center justify-center rounded-md text-sm shadow transition" aria-label="Delete">
                      <i class="fas fa-trash-alt"></i>
                    </button>
                  </form>
                </div>
              </li>
            <?php endforeach; ?>
          <?php endif; ?>
        </ul>

      <?php elseif ($tab === 'pending'): ?>
        <h2 class="text-lg font-bold mb-2">🕵️ Pending Uploads (Admin Review)</h2>

        <div class="border dark:border-gray-700 rounded p-3 max-h-[32rem] overflow-auto bg-gray-50 dark:bg-gray-700">
          <?php if (!$pending): ?>
            <p class="text-sm text-gray-700 dark:text-gray-200">No pending uploads.</p>
          <?php else: ?>
            <ul class="space-y-2">
              <?php foreach ($pending as $p): ?>
                <li class="flex flex-col md:flex-row md:items-center md:justify-between gap-2 p-2 rounded bg-white/60 dark:bg-gray-800/60">
                  <div class="min-w-0">
                    <div class="font-medium truncate" title="<?php echo h((string)$p['original_name']); ?>"><?php echo h((string)$p['original_name']); ?></div>
                    <div class="text-xs text-gray-500">
                      <?php echo h((string)$p['uploaded_at']); ?> • <?php echo (int)$p['size_bytes']; ?> bytes
                      • by <?php echo h((string)$p['uploaded_by_user']); ?>
                      <?php if (!empty($p['ip_address'])): ?> • IP <?php echo h((string)$p['ip_address']); ?><?php endif; ?>
                      <?php if (!empty($p['scan_status'])): ?> • scan: <?php echo h((string)$p['scan_status']); ?><?php endif; ?>
                    </div>
                  </div>
                  <div class="flex gap-2">
                    <form method="post" class="m-0" onsubmit="return confirm('Approve this upload?')">
                      <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
                      <input type="hidden" name="action" value="approve_pending">
                      <input type="hidden" name="pending_id" value="<?php echo (int)$p['id']; ?>">
                      <button class="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-md text-sm">Approve</button>
                    </form>
                    <form method="post" class="m-0" onsubmit="return confirm('Reject this upload?')">
                      <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
                      <input type="hidden" name="action" value="reject_pending">
                      <input type="hidden" name="pending_id" value="<?php echo (int)$p['id']; ?>">
                      <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md text-sm">Reject</button>
                    </form>
                  </div>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

      <?php elseif ($tab === 'users'): ?>
        <h2 class="text-lg font-bold mb-2">👥 User Settings</h2>

        <?php
          $userRows = $pdo->query("SELECT id, username, role, can_upload, can_view, can_download, upload_quota_bytes, max_file_bytes, last_login_at, last_login_ip FROM users ORDER BY username ASC")->fetchAll();
        ?>
        <div class="border dark:border-gray-700 rounded p-3 max-h-[32rem] overflow-auto bg-gray-50 dark:bg-gray-700">
          <ul class="space-y-3">
            <?php foreach ($userRows as $u): if ((string)$u['role'] !== 'user') continue; ?>
              <li class="p-3 rounded bg-white/60 dark:bg-gray-800/60">
                <div class="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                  <div class="min-w-0">
                    <div class="font-semibold truncate"><?php echo h((string)$u['username']); ?></div>
                    <div class="text-xs text-gray-500">Last login: <?php echo h((string)($u['last_login_at'] ?? 'N/A')); ?> • IP <?php echo h((string)($u['last_login_ip'] ?? 'N/A')); ?></div>
                  </div>
                  <div class="flex gap-2">
                    <form method="post" class="m-0" onsubmit="return confirm('Delete user <?php echo h((string)$u['username']); ?>?')">
                      <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
                      <input type="hidden" name="action" value="delete_user">
                      <input type="hidden" name="user_id" value="<?php echo (int)$u['id']; ?>">
                      <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md text-sm">Delete</button>
                    </form>
                  </div>
                </div>

                <form method="post" class="mt-3 grid md:grid-cols-3 gap-3 items-end">
                  <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
                  <input type="hidden" name="action" value="update_user">
                  <input type="hidden" name="user_id" value="<?php echo (int)$u['id']; ?>">

                  <div>
                    <div class="text-sm font-medium mb-1">Capabilities</div>
                    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="can_upload" <?php echo ((int)$u['can_upload']===1)?'checked':''; ?>> Upload</label>
                    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="can_view" <?php echo ((int)$u['can_view']===1)?'checked':''; ?>> View list</label>
                    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="can_download" <?php echo ((int)$u['can_download']===1)?'checked':''; ?>> Download</label>
                  </div>

                  <div>
                    <div class="text-sm font-medium mb-1">Total quota (0 = unlimited)</div>
                    <div class="flex gap-2">
                      <input name="quota_value" type="number" min="0" class="w-28 p-2 rounded bg-gray-50 dark:bg-gray-700" value="<?php echo (int)round(((int)$u['upload_quota_bytes'])/1024/1024); ?>">
                      <select name="quota_unit" class="p-2 rounded bg-gray-50 dark:bg-gray-700">
                        <option value="KB">KB</option>
                        <option value="MB" selected>MB</option>
                        <option value="GB">GB</option>
                      </select>
                    </div>
                    <div class="text-xs text-gray-500 mt-1">Current: <?php echo h(bytes_human((int)$u['upload_quota_bytes'])); ?></div>
                  </div>

                  <div>
                    <div class="text-sm font-medium mb-1">Max per file (0 = unlimited)</div>
                    <div class="flex gap-2">
                      <input name="max_value" type="number" min="0" class="w-28 p-2 rounded bg-gray-50 dark:bg-gray-700" value="<?php echo (int)round(((int)$u['max_file_bytes'])/1024/1024); ?>">
                      <select name="max_unit" class="p-2 rounded bg-gray-50 dark:bg-gray-700">
                        <option value="KB">KB</option>
                        <option value="MB" selected>MB</option>
                        <option value="GB">GB</option>
                      </select>
                    </div>
                    <div class="text-xs text-gray-500 mt-1">Current: <?php echo h(bytes_human((int)$u['max_file_bytes'])); ?></div>
                  </div>

                  <div class="md:col-span-3">
                    <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow transition">Save</button>
                  </div>
                </form>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>

      <?php else: ?>
        <h2 class="text-lg font-bold mb-2">🔐 Assign Permissions (View/Download per file)</h2>

        <form method="get" action="<?php echo $PANEL_BASE; ?>/perms" class="mb-3 flex flex-wrap gap-2 items-center">
          <select name="user" class="p-2 text-sm rounded-md bg-gray-50 dark:bg-gray-700" required>
            <option value="">Select user…</option>
            <?php foreach ($users as $u): if (($u['role'] ?? '') !== 'user') continue; ?>
              <option value="<?php echo (int)$u['id']; ?>" <?php echo $userIdForPerm===(int)$u['id']?'selected':''; ?>>
                <?php echo h((string)$u['username']); ?>
              </option>
            <?php endforeach; ?>
          </select>
          <button class="bg-gray-800 text-white px-3 py-2 rounded-md text-sm">Load</button>
        </form>

        <?php if ($userIdForPerm > 0): ?>
          <form method="post" class="space-y-2">
            <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>">
            <input type="hidden" name="action" value="save_perms">
            <input type="hidden" name="perm_user_id" value="<?php echo (int)$userIdForPerm; ?>">

            <div class="border dark:border-gray-700 rounded p-3 max-h-96 overflow-auto bg-gray-50 dark:bg-gray-700">
              <?php if (!$files): ?>
                <p class="text-sm text-gray-700 dark:text-gray-200">No files to assign. Upload files first.</p>
              <?php else: ?>
                <?php foreach ($files as $f): $fid=(int)$f['id']; $pm=$permMap[$fid] ?? ['v'=>0,'d'=>0]; ?>
                  <div class="flex items-center justify-between gap-3 py-1 text-sm">
                    <span class="truncate" title="<?php echo h((string)$f['original_name']); ?>"><?php echo h((string)$f['original_name']); ?></span>
                    <div class="flex items-center gap-4 flex-shrink-0">
                      <label class="flex items-center gap-2"><input type="checkbox" name="allow_view[<?php echo $fid; ?>]" value="1" <?php echo ((int)($pm['v']??0)===1)?'checked':''; ?>> View</label>
                      <label class="flex items-center gap-2"><input type="checkbox" name="allow_download[<?php echo $fid; ?>]" value="1" <?php echo ((int)($pm['d']??0)===1)?'checked':''; ?>> Download</label>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>

            <button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md shadow transition">Save Permissions</button>
          </form>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  <?php endif; ?>

</main>

<!-- Preview Modal -->
<div id="file-viewer-modal" class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 hidden z-50">
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-5xl h-full max-h-[90vh] flex flex-col">
    <header class="p-3 border-b dark:border-gray-600 flex justify-between items-center flex-shrink-0">
      <h3 id="modal-filename" class="font-semibold truncate text-gray-800 dark:text-gray-200"></h3>
      <button id="modal-close-button" class="text-gray-500 hover:text-gray-900 dark:hover:text-white text-2xl w-8 h-8">&times;</button>
    </header>
    <main id="modal-content" class="p-4 overflow-auto flex-grow flex items-center justify-center"></main>
  </div>
</div>

<?php
// ===== Footer Data =====
$appVersion = $APP_VERSION ?? 'v0.0.0';
$clientIp = function_exists('get_client_ip') ? get_client_ip() : ($_SERVER['REMOTE_ADDR'] ?? 'unknown');

// last login (from current_user())
$lastLoginAt = $me['last_login_at'] ?? null;
$lastLoginPretty = 'N/A';
if ($lastLoginAt) {
    try {
        $dt = new DateTime((string)$lastLoginAt, new DateTimeZone('UTC'));
        $dt->setTimezone(new DateTimeZone('Asia/Dhaka'));
        $lastLoginPretty = $dt->format('Y-m-d h:i:s A');
    } catch (Throwable $e) {
        $lastLoginPretty = (string)$lastLoginAt;
    }
}



$lastLoginIp = $me['last_login_ip'] ?? null;

// load time
$loadMs = (int)round((microtime(true) - $__PAGE_T0) * 1000);

/// ===== Storage usage (admin-only) =====
// NOTE: disk_total_space() shows SERVER disk (can be huge on shared hosting).
// We'll show REAL app usage based on $FILES_DIR and $DATA_DIR.

$appUsedBytes = null;
$appFilesBytes = null;

if (!empty($isAdmin)) {
    // Fast-ish folder size calculator (iterative)
    $calc_dir_size = function (string $dir): int {
        $size = 0;
        if (!is_dir($dir)) return 0;

        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($it as $f) {
            try {
                if ($f->isFile()) $size += $f->getSize();
            } catch (Throwable $e) {
                // ignore unreadable files
            }
        }
        return $size;
    };

    // Total app footprint: data/ (includes sqlite + files)
    $appUsedBytes = $calc_dir_size($DATA_DIR ?? (__DIR__ . '/data'));

    // Just uploaded files folder
    $appFilesBytes = $calc_dir_size($FILES_DIR ?? (__DIR__ . '/data/files'));
}

function fmt_bytes(?float $b): string {
    if ($b === null || $b < 0) return 'N/A';
    $units = ['B','KB','MB','GB','TB'];
    $i = 0;
    while ($b >= 1024 && $i < count($units) - 1) { $b /= 1024; $i++; }
    return round($b, 2) . ' ' . $units[$i];
}

$userRole = $me['role'] ?? 'guest';
$userRoleLabel = ucfirst((string)$userRole);
?>

<footer class="bg-black bg-opacity-30 text-white text-xs py-4 mt-6">
  <div class="container mx-auto px-4 flex flex-col gap-2">

    <div class="flex flex-col md:flex-row justify-between items-center gap-2 text-center md:text-left">
      <div>
        © 2023–<?php echo date('Y'); ?>
        <strong>Khondoker Moin Hossain</strong> | All rights reserved.
      </div>

      <div class="flex items-center gap-4">
        <span class="opacity-80">Version: <strong><?php echo htmlspecialchars($appVersion, ENT_QUOTES, 'UTF-8'); ?></strong></span>
        <span class="opacity-80">Server: <strong class="text-green-400">● Online</strong></span>
      </div>

      <div class="opacity-80">
        Logged in as: <strong class="capitalize"><?php echo htmlspecialchars($userRoleLabel, ENT_QUOTES, 'UTF-8'); ?></strong>
      </div>
    </div>

    <div class="flex flex-col md:flex-row justify-between items-center gap-2 text-center md:text-left opacity-90">
      <div>
        Client IP: <strong><?php echo htmlspecialchars((string)$clientIp, ENT_QUOTES, 'UTF-8'); ?></strong>
      </div>

      <div>
        Last login:
        <strong><?php echo htmlspecialchars($lastLoginPretty, ENT_QUOTES, 'UTF-8'); ?></strong>
        <?php if ($lastLoginIp): ?>
          <span class="opacity-75">(<?php echo htmlspecialchars((string)$lastLoginIp, ENT_QUOTES, 'UTF-8'); ?>)</span>
        <?php endif; ?>
      </div>

      <?php if (!empty($isAdmin)): ?>
        <div>
          <button id="adminInfoToggle"
                  class="bg-gray-200 text-gray-900 dark:bg-gray-700 dark:text-white px-3 py-1 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition">
            Admin info: <span id="adminInfoState">Show</span>
          </button>
        </div>
      <?php endif; ?>
    </div>

    <?php if (!empty($isAdmin)): ?>
      <div id="adminOnlyInfo" class="hidden mt-2 border-t border-white/10 pt-3 flex flex-col md:flex-row justify-between items-center gap-2">
        <div class="opacity-90">
          Disk: <strong><?php echo fmt_bytes($appUsedBytes); ?></strong>
<span class="opacity-75"> (Files: <?php echo fmt_bytes($appFilesBytes); ?>)</span>

          <?php if ($diskPct !== null): ?>
            <span class="opacity-75">(<?php echo (int)$diskPct; ?>%)</span>
          <?php endif; ?>
        </div>

        <div class="opacity-90">
          Page load: <strong><?php echo (int)$loadMs; ?> ms</strong>
        </div>
      </div>
    <?php endif; ?>

  </div>
</footer>

<script>
function toggleTheme() {
  const html = document.documentElement;
  if (html.classList.contains("dark")) { html.classList.remove("dark"); localStorage.theme = "light"; }
  else { html.classList.add("dark"); localStorage.theme = "dark"; }
}

// Search + Sort
document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  const fileList = document.getElementById('file-list');
  if (!fileList) return;

  const getItems = () => Array.from(fileList.querySelectorAll('.file-item'));

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const t = searchInput.value.toLowerCase();
      getItems().forEach(item => item.style.display = (item.dataset.filename || '').includes(t) ? 'flex' : 'none');
    });
  }

  const sortFiles = (direction) => {
    const items = getItems();
    const visible = items.filter(i => i.style.display !== 'none');
    const hidden  = items.filter(i => i.style.display === 'none');

    visible.sort((a,b) => {
      const an = a.dataset.filename || '';
      const bn = b.dataset.filename || '';
      return direction === 'az' ? an.localeCompare(bn) : bn.localeCompare(an);
    });

    [...visible, ...hidden].forEach(i => fileList.appendChild(i));
  };

  const az = document.getElementById('sort-az');
  const za = document.getElementById('sort-za');
  if (az) az.addEventListener('click', () => sortFiles('az'));
  if (za) za.addEventListener('click', () => sortFiles('za'));
});

// Preview modal
const modal = document.getElementById('file-viewer-modal');
const modalContent = document.getElementById('modal-content');
const modalFilename = document.getElementById('modal-filename');
const closeModalButton = document.getElementById('modal-close-button');

function closeModal() {
  modal.classList.add('hidden');
  modalContent.innerHTML = '';
}
closeModalButton.addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.classList.contains('hidden')) closeModal(); });

document.querySelectorAll('.view-button').forEach(btn => {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.id;
    const filename = btn.dataset.filename || 'File';
    const ext = (btn.dataset.ext || '').toLowerCase();
    const isText = btn.dataset.text === '1';

    modalFilename.textContent = filename;
    modalContent.innerHTML = '<i class="fas fa-spinner fa-spin text-4xl"></i>';
    modal.classList.remove('hidden');

    const imageExt = ['png','jpg','jpeg','gif','svg','webp','bmp','ico'];
    const audioExt = ['mp3','wav','ogg','m4a','aac','flac'];
    const videoExt = ['mp4','webm','ogv','mov','mkv'];

    const inlineUrl = `/preview/${id}`;

    try {
      if (imageExt.includes(ext)) {
        modalContent.innerHTML = `<img src="${inlineUrl}" alt="${filename}" class="object-contain w-full h-full">`;
        return;
      }
      if (ext === 'pdf') {
        modalContent.innerHTML = `<iframe src="${inlineUrl}" class="w-full h-full border-0" title="${filename}"></iframe>`;
        return;
      }
      if (audioExt.includes(ext)) {
        modalContent.innerHTML = `<audio controls class="w-full"><source src="${inlineUrl}"></audio>`;
        return;
      }
      if (videoExt.includes(ext)) {
        modalContent.innerHTML = `<video controls class="w-full h-full"><source src="${inlineUrl}"></video>`;
        return;
      }

      if (isText) {
        const r = await fetch(inlineUrl);
        if (!r.ok) throw new Error('Could not load file');
        const text = await r.text();
        const sanitized = text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
        modalContent.innerHTML = `<pre class="whitespace-pre-wrap text-sm mono w-full"><code>${sanitized}</code></pre>`;
        return;
      }

      modalContent.innerHTML =
        `<div class="text-center p-8">
          <div class="text-4xl">🚫</div>
          <p class="mt-2">Preview not available for this file type.</p>
          <a class="inline-block mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
             href="/file/${id}"><i class="fas fa-download"></i> Download</a>
        </div>`;
    } catch (err) {
      modalContent.innerHTML =
        `<div class="text-center text-red-500 p-8">
          <div class="text-4xl">⚠️</div>
          <p class="mt-2">Could not load preview.</p>
        </div>`;
    }
  });
});

// Admin-only toggle
(function(){
  const btn = document.getElementById('adminInfoToggle');
  const box = document.getElementById('adminOnlyInfo');
  const state = document.getElementById('adminInfoState');
  if (!btn || !box || !state) return;

  const key = 'adminInfoVisible';
  const apply = (v) => {
    box.classList.toggle('hidden', !v);
    state.textContent = v ? 'Hide' : 'Show';
  };

  const saved = localStorage.getItem(key);
  const visible = saved === '1';
  apply(visible);

  btn.addEventListener('click', () => {
    const now = box.classList.contains('hidden');
    apply(now);
    localStorage.setItem(key, now ? '1' : '0');
  });
})();
</script>

</body>
</html>
