<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

const LOGIN_URL = '/index.php'; // আপনার login page যদি index.php হয় -> '/index.php' করুন

function is_https_now(): bool {
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
        (!empty($_SERVER['HTTP_CF_VISITOR']) && strpos((string)$_SERVER['HTTP_CF_VISITOR'], '"https"') !== false)
    );
}

function get_client_ip(): string {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return trim((string)$_SERVER['HTTP_CF_CONNECTING_IP']);
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($parts[0]);
    }
    return trim((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
}

function start_session(): void {
    global $COOKIE_SECURE, $COOKIE_SAMESITE, $COOKIE_HTTPONLY;

    if (session_status() === PHP_SESSION_ACTIVE) return;

    // Safe cookie defaults
    $secure = isset($COOKIE_SECURE) ? (bool)$COOKIE_SECURE : is_https_now();
    $sameSite = isset($COOKIE_SAMESITE) ? (string)$COOKIE_SAMESITE : 'Lax';
    $httpOnly = isset($COOKIE_HTTPONLY) ? (bool)$COOKIE_HTTPONLY : true;

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => $httpOnly,
        'samesite' => $sameSite,
    ]);

    session_start();
}

function is_logged_in(): bool {
    return !empty($_SESSION['uid']);
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: ' . LOGIN_URL);
        exit;
    }
}

function require_admin(): void {
    require_login();
    if (($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }
}

/**
 * Login attempt:
 * - checks password_hash
 * - sets session uid/username/role
 * - updates users.last_login_at + last_login_ip
 */
function attempt_login(string $username, string $password): bool {
    $username = trim($username);
    if ($username === '' || $password === '') return false;

    migrate();
    $pdo = db();

    $stmt = $pdo->prepare("SELECT id, username, pass_hash, role, can_upload, can_view, can_download, upload_quota_bytes, max_file_bytes FROM users WHERE username=:u LIMIT 1");
    $stmt->execute([':u' => $username]);
    $u = $stmt->fetch();
    if (!$u) return false;

    if (!password_verify($password, (string)$u['pass_hash'])) return false;

    // set session
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['username'] = (string)$u['username'];
    $_SESSION['role'] = (string)$u['role'];

    // cache capabilities + quota in session for fast permission checks
    $_SESSION['can_upload'] = (int)($u['can_upload'] ?? 0);
    $_SESSION['can_view'] = (int)($u['can_view'] ?? 1);
    $_SESSION['can_download'] = (int)($u['can_download'] ?? 1);
    $_SESSION['upload_quota_bytes'] = (int)($u['upload_quota_bytes'] ?? 0);
    $_SESSION['max_file_bytes'] = (int)($u['max_file_bytes'] ?? 0);

    // update last login fields
    $ip = get_client_ip();
    $upd = $pdo->prepare("UPDATE users SET last_login_at = datetime('now'), last_login_ip = :ip WHERE id = :id");
    $upd->execute([':ip' => $ip, ':id' => (int)$u['id']]);

    return true;
}

function logout_now(): void {
    $_SESSION = [];
    if (session_id() !== '') {
        session_destroy();
    }
    header('Location: ' . LOGIN_URL);
    exit;
}

/**
 * Current user:
 * session + DB (for last_login info)
 */
function current_user(): array {
    $uid = (int)($_SESSION['uid'] ?? 0);
    if ($uid <= 0) {
        return ['id'=>0,'username'=>'','role'=>''];
    }

    // Pull profile from DB (safe)
    try {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT last_login_at, last_login_ip, can_upload, can_view, can_download, upload_quota_bytes, max_file_bytes FROM users WHERE id=:id");
        $stmt->execute([':id' => $uid]);
        $row = $stmt->fetch() ?: [];
    } catch (Throwable $e) {
        $row = [];
    }

    return [
        'id' => $uid,
        'username' => (string)($_SESSION['username'] ?? ''),
        'role' => (string)($_SESSION['role'] ?? ''),
        'can_upload' => (int)($row['can_upload'] ?? ($_SESSION['can_upload'] ?? 0)),
        'can_view' => (int)($row['can_view'] ?? ($_SESSION['can_view'] ?? 1)),
        'can_download' => (int)($row['can_download'] ?? ($_SESSION['can_download'] ?? 1)),
        'upload_quota_bytes' => (int)($row['upload_quota_bytes'] ?? ($_SESSION['upload_quota_bytes'] ?? 0)),
        'max_file_bytes' => (int)($row['max_file_bytes'] ?? ($_SESSION['max_file_bytes'] ?? 0)),
        'last_login_at' => $row['last_login_at'] ?? null,
        'last_login_ip' => $row['last_login_ip'] ?? null,
    ];
}

function user_can_upload(array $u): bool {
    return (($u['role'] ?? '') === 'admin') || ((int)($u['can_upload'] ?? 0) === 1);
}
function user_can_view(array $u): bool {
    return (($u['role'] ?? '') === 'admin') || ((int)($u['can_view'] ?? 1) === 1);
}
function user_can_download(array $u): bool {
    return (($u['role'] ?? '') === 'admin') || ((int)($u['can_download'] ?? 1) === 1);
}
