<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

start_session();
require_login();
migrate();

$pdo = db();
$me = current_user();

$fileId = (int)($_GET['id'] ?? 0);
if ($fileId <= 0) { http_response_code(400); exit('Bad request'); }

$stmt = $pdo->prepare("SELECT id, original_name, stored_name, mime, size_bytes FROM files WHERE id=:id");
$stmt->execute([':id' => $fileId]);
$f = $stmt->fetch();
if (!$f) { http_response_code(404); exit('Not found'); }

if ($me['role'] !== 'admin') {
    if (!user_can_view($me)) { http_response_code(403); exit('Viewing disabled for this user'); }
    $stmt = $pdo->prepare("SELECT 1 FROM permissions WHERE user_id=:u AND file_id=:f AND can_view=1");
    $stmt->execute([':u' => $me['id'], ':f' => $fileId]);
    if (!$stmt->fetch()) { http_response_code(403); exit('Forbidden'); }
}

$path = $FILES_DIR . DIRECTORY_SEPARATOR . $f['stored_name'];
$real = realpath($path);
$base = realpath($FILES_DIR);

if (!$real || !$base || strpos($real, $base) !== 0 || !is_file($real)) {
    http_response_code(404);
    exit('Not found');
}

session_write_close();
set_time_limit(0);
while (ob_get_level() > 0) { @ob_end_clean(); }

$mime = $f['mime'] ?: 'application/octet-stream';

// Prevent XSS via inline preview of active content (e.g., HTML/SVG).
// These types are still downloadable via download.php.
$dangerousInline = [
    'text/html',
    'application/xhtml+xml',
    'image/svg+xml',
];
if (in_array(strtolower((string)$mime), $dangerousInline, true)) {
    $mime = 'application/octet-stream';
    $forceAttachment = true;
} else {
    $forceAttachment = false;
}

// Preview headers
header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($real));
$disp = $forceAttachment ? 'attachment' : 'inline';
header('Content-Disposition: ' . $disp . '; filename="' . str_replace(['"', "\r", "\n"], '', (string)$f['original_name']) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=0, no-store');

readfile($real);
exit;
