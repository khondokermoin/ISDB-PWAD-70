<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

start_session();
require_login();

if (($_SESSION['role'] ?? '') === 'admin') {
    header('Location: admin.php');
} else {
    header('Location: admin.php?view=user');
}
exit;
