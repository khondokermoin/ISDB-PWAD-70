<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
date_default_timezone_set('Asia/Dhaka');


$BASE_DIR  = __DIR__;
$DATA_DIR  = $BASE_DIR . DIRECTORY_SEPARATOR . 'data';
$DB_PATH   = $DATA_DIR . DIRECTORY_SEPARATOR . 'app.sqlite';
$FILES_DIR = $DATA_DIR . DIRECTORY_SEPARATOR . 'files';
$PENDING_DIR = $DATA_DIR . DIRECTORY_SEPARATOR . 'pending';

if (!is_dir($DATA_DIR))  { @mkdir($DATA_DIR, 0755, true); }
if (!is_dir($FILES_DIR)) { @mkdir($FILES_DIR, 0755, true); }
if (!is_dir($PENDING_DIR)) { @mkdir($PENDING_DIR, 0755, true); }

$APP_NAME    = "Secure File Server";
$APP_VERSION = "v3.2.1"; // ✅ footer/version এর জন্য (এখানে বদলাবেন)

// ---- Upload safety defaults ----
// Block dangerous extensions even if web server misconfigured.
$BLOCKED_EXTENSIONS = [
    'php','phtml','pht','phar','php3','php4','php5','php7','php8',
    'cgi','pl','py','rb','sh','bash','zsh','cmd','bat','ps1','psm1',
    'htaccess','ini','conf','config','env','sql','sqlite','db',
];

// Allow common safe file types (admin can still upload other types if you expand this list).
$ALLOWED_EXTENSIONS = [
    // documents
    'txt','md','log','pdf','doc','docx','xls','xlsx','ppt','pptx','csv','rtf',
    // code / markup (served via PHP download/preview, not directly)
    'html','htm','css','js','json','xml','yml','yaml',
    // images
    'jpg','jpeg','png','gif','webp','svg',
    // archives
    'zip','rar','7z','tar','gz',
    // media
    'mp3','wav','mp4','mkv','avi','mov',
];

// Hard cap as a safety net (bytes). Set to 0 to disable.
$HARD_MAX_UPLOAD_BYTES = 50 * 1024 * 1024; // 50MB

// ---- Cookie / Session Security ----
// Auto-detect HTTPS (Hostinger/Proxy/Cloudflare friendly)
$isHttps = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['HTTP_CF_VISITOR']) && strpos((string)$_SERVER['HTTP_CF_VISITOR'], '"https"') !== false)
);

$COOKIE_SECURE   = $isHttps;  // ✅ HTTPS হলে true, না হলে false (না হলে login সমস্যা হতে পারে)
$COOKIE_HTTPONLY = true;      // ✅ JS থেকে cookie access বন্ধ (security)
$COOKIE_SAMESITE = "Lax";     // ✅ CSRF risk কমায় (Top-level navigation ঠিক থাকে)

// Optional: session cookie params set centrally (auth.php/start_session আগে include হলে কাজে দেবে)
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'domain'   => '',
    'secure'   => $COOKIE_SECURE,
    'httponly' => $COOKIE_HTTPONLY,
    'samesite' => $COOKIE_SAMESITE,
]);
