# Secure File Server (PHP + SQLite)

## Quick install
1. Upload the project to your hosting (Apache recommended). Point your domain/subdomain to the project folder.
2. Ensure PHP has these enabled: `pdo_sqlite`, `fileinfo`.
3. Visit `install.php` once to create the first **admin** user.
4. **Delete `install.php` after installation**.

## Important security notes
- Do **not** share or commit the `data/` folder. It contains the SQLite database and uploaded files.
- For best security, store uploads **outside the public web root**. If you can’t, ensure `/data` and `/data/files` are not publicly accessible.
- If you use Cloudflare **Flexible SSL**, disable the HTTPS redirect in `.htaccess` to avoid redirect loops.

## Default folders
- `data/app.sqlite` : SQLite database (auto-created)
- `data/files/`     : approved files
- `data/pending/`   : user uploads awaiting admin approval
