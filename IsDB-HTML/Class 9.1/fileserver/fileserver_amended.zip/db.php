<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function db(): PDO {
    static $pdo = null;
    global $DB_PATH;

    if ($pdo instanceof PDO) return $pdo;

    $pdo = new PDO('sqlite:' . $DB_PATH, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Reduce "database is locked" + speed tweaks
    try {
        $pdo->exec("PRAGMA foreign_keys = ON;");
        $pdo->exec("PRAGMA busy_timeout = 5000;");     // wait up to 5s for lock
        $pdo->exec("PRAGMA journal_mode = WAL;");
        $pdo->exec("PRAGMA synchronous = NORMAL;");
        $pdo->exec("PRAGMA temp_store = MEMORY;");
        $pdo->exec("PRAGMA cache_size = -8000;");      // ~8MB
    } catch (Throwable $e) {}

    return $pdo;
}

function migrate(): void {
    static $done = false;
    if ($done) return;

    global $DATA_DIR;
    $flag = $DATA_DIR . DIRECTORY_SEPARATOR . 'schema_ready.flag';

    $pdo = db();

    // --- Base schema ---
    $pdo->exec("
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        pass_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','user')),
        can_upload INTEGER NOT NULL DEFAULT 0,
        can_view INTEGER NOT NULL DEFAULT 1,
        can_download INTEGER NOT NULL DEFAULT 1,
        upload_quota_bytes INTEGER NOT NULL DEFAULT 0,
        max_file_bytes INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        last_login_at TEXT,
        last_login_ip TEXT
      );
    ");

    $pdo->exec("
      CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        original_name TEXT NOT NULL,
        stored_name TEXT UNIQUE NOT NULL,
        mime TEXT,
        size_bytes INTEGER NOT NULL DEFAULT 0,
        uploaded_by INTEGER,
        uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
        ip_address TEXT,
        scan_status TEXT NOT NULL DEFAULT 'pending' CHECK(scan_status IN ('pending','clean','infected','skipped')),
        approved_by INTEGER,
        approved_at TEXT,
        FOREIGN KEY(uploaded_by) REFERENCES users(id)
      );
    ");

    $pdo->exec("
      CREATE TABLE IF NOT EXISTS permissions (
        user_id INTEGER NOT NULL,
        file_id INTEGER NOT NULL,
        can_view INTEGER NOT NULL DEFAULT 1,
        can_download INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY(user_id, file_id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(file_id) REFERENCES files(id)
      );
    ");

    $pdo->exec("
      CREATE TABLE IF NOT EXISTS pending_uploads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        original_name TEXT NOT NULL,
        temp_name TEXT UNIQUE NOT NULL,
        mime TEXT,
        size_bytes INTEGER NOT NULL DEFAULT 0,
        uploaded_by INTEGER NOT NULL,
        uploaded_at TEXT NOT NULL DEFAULT (datetime('now')),
        ip_address TEXT,
        scan_status TEXT NOT NULL DEFAULT 'pending' CHECK(scan_status IN ('pending','clean','infected','skipped')),
        FOREIGN KEY(uploaded_by) REFERENCES users(id)
      );
    ");

    // --- Indexes ---
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_perm_user ON permissions(user_id);");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_perm_file ON permissions(file_id);");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_files_uploaded_at ON files(uploaded_at);");

    // --- Backward compatible: add columns if old DB exists ---
    // (SQLite doesn't support IF NOT EXISTS for ADD COLUMN)
    try { $pdo->exec("ALTER TABLE users ADD COLUMN last_login_at TEXT;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN last_login_ip TEXT;"); } catch (Throwable $e) {}

    // users capabilities + quota
    try { $pdo->exec("ALTER TABLE users ADD COLUMN can_upload INTEGER NOT NULL DEFAULT 0;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN can_view INTEGER NOT NULL DEFAULT 1;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN can_download INTEGER NOT NULL DEFAULT 1;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN upload_quota_bytes INTEGER NOT NULL DEFAULT 0;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN max_file_bytes INTEGER NOT NULL DEFAULT 0;"); } catch (Throwable $e) {}

    // files tracking
    try { $pdo->exec("ALTER TABLE files ADD COLUMN ip_address TEXT;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE files ADD COLUMN scan_status TEXT NOT NULL DEFAULT 'pending';"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE files ADD COLUMN approved_by INTEGER;"); } catch (Throwable $e) {}
    try { $pdo->exec("ALTER TABLE files ADD COLUMN approved_at TEXT;"); } catch (Throwable $e) {}

    // permissions can_view
    try { $pdo->exec("ALTER TABLE permissions ADD COLUMN can_view INTEGER NOT NULL DEFAULT 1;"); } catch (Throwable $e) {}

    // Mark schema ready
    @file_put_contents($flag, "ok\n");

    $done = true;
}
