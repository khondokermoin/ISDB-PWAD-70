<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

start_session();
require_admin();
migrate();
csrf_init();
csrf_verify();

// release session lock early
session_write_close();

$pdo = db();
$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) { header('Location: admin.php?tab=files'); exit; }

$stmt = $pdo->prepare("SELECT stored_name FROM files WHERE id=:id");
$stmt->execute([':id'=>$id]);
$row = $stmt->fetch();

if (!$row) { header('Location: admin.php?tab=files'); exit; }

$stored = (string)$row['stored_name'];
$path = $FILES_DIR . DIRECTORY_SEPARATOR . $stored;

// Path safety (defense in depth)
$real = realpath($path);
$base = realpath($FILES_DIR);
$safeToDelete = ($real && $base && strpos($real, $base) === 0 && is_file($real));

// Fast DB cleanup in a transaction
$pdo->beginTransaction();
$pdo->prepare("DELETE FROM permissions WHERE file_id=:id")->execute([':id'=>$id]);
$pdo->prepare("DELETE FROM files WHERE id=:id")->execute([':id'=>$id]);
$pdo->commit();

// Then delete file from disk (I/O can be slow; doing after DB is fine)
if ($safeToDelete) { @unlink($real); }

header('Location: admin.php?tab=files');
exit;
