<?php
declare(strict_types=1);

/**
 * Install / bootstrap
 *
 * BUGFIX: Older versions locked install.php as soon as the SQLite file existed.
 * But other pages (like index.php) call migrate(), which creates the DB file,
 * so visiting the login page first could permanently lock installation.
 *
 * We now lock ONLY after an admin account exists.
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

start_session();
migrate();
csrf_init();

$pdo = db();
$adminExists = ((int)($pdo->query("SELECT COUNT(*) AS c FROM users WHERE role='admin'")->fetch()['c'] ?? 0)) > 0;

if ($adminExists) {
    http_response_code(403);
    exit('Install locked');
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $username = trim($_POST['username'] ?? 'admin');
    $pass = (string)($_POST['password'] ?? '');

    if ($adminExists) {
        $msg = "Admin already exists. Please delete install.php for security.";
    } elseif ($username === '' || strlen($pass) < 8) {
        $msg = "Username required and password must be at least 8 chars.";
    } else {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, pass_hash, role) VALUES (:u, :h, 'admin')");
        $stmt->execute([':u' => $username, ':h' => $hash]);
        $msg = "✅ Admin created. Now delete install.php and go to index.php";
        $adminExists = true;
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Install - Secure File Server</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-6">
  <div class="bg-white p-6 rounded-lg shadow w-full max-w-md">
    <h1 class="text-xl font-bold mb-4">Install / Create Admin</h1>

    <?php if ($msg): ?>
      <div class="p-3 mb-3 rounded bg-yellow-100 text-yellow-900"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <?php if (!$adminExists): ?>
    <form method="post" class="space-y-3">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
      <div>
        <label class="text-sm">Admin Username</label>
        <input name="username" value="admin" class="w-full border p-2 rounded" required>
      </div>
      <div>
        <label class="text-sm">Admin Password (min 8)</label>
        <input type="password" name="password" class="w-full border p-2 rounded" required>
      </div>
      <button class="w-full bg-blue-600 text-white p-2 rounded">Create Admin</button>
    </form>
    <?php else: ?>
      <p class="text-sm text-gray-700">Admin exists. For security, delete <b>install.php</b>.</p>
      <a class="inline-block mt-3 text-blue-700 underline" href="index.php">Go to login</a>
    <?php endif; ?>
  </div>
</body>
</html>
