<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

start_session();
require_login();
migrate();

$pdo = db();
$me = current_user();

$fileId = (int)($_GET['id'] ?? 0);
if ($fileId <= 0) { http_response_code(400); exit('Bad request'); }

// File info
$stmt = $pdo->prepare("SELECT id, original_name, stored_name, mime, size_bytes FROM files WHERE id=:id");
$stmt->execute([':id'=>$fileId]);
$f = $stmt->fetch();
if (!$f) { http_response_code(404); exit('Not found'); }

// Permission check (admin সব পারবে)
if ($me['role'] !== 'admin') {
    if (!user_can_download($me)) { http_response_code(403); exit('Downloads disabled for this user'); }
    $stmt = $pdo->prepare("SELECT 1 FROM permissions WHERE user_id=:u AND file_id=:f AND can_download=1");
    $stmt->execute([':u'=>$me['id'], ':f'=>$fileId]);
    if (!$stmt->fetch()) { http_response_code(403); exit('Forbidden'); }
}

$path = $FILES_DIR . DIRECTORY_SEPARATOR . $f['stored_name'];
$real = realpath($path);
$base = realpath($FILES_DIR);

// Path safety
if (!$real || !$base || strpos($real, $base) !== 0 || !is_file($real)) {
    http_response_code(404);
    exit('Not found');
}

// IMPORTANT: Release session lock so other pages stay fast during big download
session_write_close();
set_time_limit(0);

// Clean output buffering
while (ob_get_level() > 0) { @ob_end_clean(); }

// Headers
$mime = $f['mime'] ?: 'application/octet-stream';
$fname = str_replace(["\r","\n",'"'], '', (string)$f['original_name']);

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($real));
header('Content-Disposition: attachment; filename="' . $fname . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=0, no-store');

// Stream file (fast)
$fp = fopen($real, 'rb');
if ($fp === false) { http_response_code(500); exit('Failed to open file'); }

$chunk = 1024 * 1024; // 1MB
while (!feof($fp)) {
    $buf = fread($fp, $chunk);
    if ($buf === false) break;
    echo $buf;
    flush();
}
fclose($fp);
exit;
